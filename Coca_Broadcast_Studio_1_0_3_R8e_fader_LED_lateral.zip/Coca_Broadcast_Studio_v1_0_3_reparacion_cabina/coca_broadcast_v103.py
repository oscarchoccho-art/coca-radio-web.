"""Coca Broadcast Studio 0.7 - micrófono MUTE, mezcla y grabación WAV."""
import os
import queue
import threading
import wave
import math
import json
import random
import datetime
import tempfile
import subprocess
import sqlite3
import time
import shutil
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import numpy as np
import sounddevice as sd
import soundfile as sf
from scipy.signal import resample_poly, butter, sosfilt

RATE = 44100
BLOCK = 1024
BG = '#07162c'
THEMES = {
    'Azul profesional': ('#102440', '#203b61', '#27c8f4'),
    'Negro elegante': ('#111318', '#30343c', '#d6e0ec'),
    'Verde estudio': ('#101f1a', '#244838', '#4bd49a'),
    'Morado DJ': ('#1b1432', '#3e2a67', '#b38aff'),
    'Rojo broadcast': ('#2a151b', '#59303a', '#ff6978'),
    'Dorado premium': ('#211d17', '#4a3e2b', '#e5b95c'),
}


class App:
    def __init__(self, root):
        self.root = root
        self.theme_path = os.path.join(os.path.expanduser('~'), 'CocaBroadcastStudio', 'apariencia.json')
        self.theme_name = tk.StringVar(value='Azul profesional')
        self.load_theme_settings()
        root.title('Coca Broadcast Studio - 1.0.3-R8e • Consola compacta LED')
        root.geometry('1060x730')
        root.minsize(850, 570)
        root.configure(bg=BG)
        self.tracks = []
        self.current_idx = None
        self.auto_mode = tk.BooleanVar(value=False)
        self.shuffle_mode = tk.BooleanVar(value=False)
        self.hour_enabled = tk.BooleanVar(value=False)
        self.hour_interval = tk.StringVar(value='60')
        self.station_name = tk.StringVar(value='Coca Radio')
        self.station_slogan = tk.StringVar(value='¡Escucha sin fronteras, explora nuevos sonidos!')
        self.hour_status = tk.StringVar(value='Locución horaria desactivada')
        self.hour_source = tk.StringVar(value='windows')
        self.hour_folder = tk.StringVar(value='')
        self.last_hour_slot = None
        self.announcement_queue = queue.Queue(maxsize=2)
        self.announcement_audio = None
        self.announcement_pos = 0
        self.announcement_generating = False
        self.track_finished = queue.Queue(maxsize=2)
        self.jingle_finished = queue.Queue(maxsize=2)
        self.jingle_paths = []
        self.jingle_audio = None
        self.jingle_pos = 0
        self.jingle_auto = tk.BooleanVar(value=False)
        self.jingle_every = tk.StringVar(value='3')
        self.jingle_volume = tk.DoubleVar(value=75)
        self.jingle_status = tk.StringVar(value='Sin jingles cargados')
        self.songs_since_jingle = 0
        self.jingle_cursor = 0
        self.resume_after_jingle = False
        self.library_db = os.path.join(os.path.expanduser('~'), 'CocaBroadcastStudio', 'biblioteca.db')
        self.library_events = queue.Queue()
        self.library_query = tk.StringVar()
        self.library_status = tk.StringVar(value='Biblioteca lista para importar carpetas.')
        self.library_scan_running = False
        self.library_search_job = None
        self.playlist_path = os.path.join(os.path.expanduser('~'), 'CocaBroadcastStudio', 'playlist.json')
        # Dos tornamesas mutuamente excluyentes y fondo independiente.
        self.deck_files = {'A': '', 'B': ''}
        self.deck_audio = {'A': None, 'B': None}
        self.deck_pos = {'A': 0, 'B': 0}
        self.deck_active = None
        self.deck_playing = False
        self.deck_running = {'A': False, 'B': False}
        self.deck_mode = tk.StringVar(value='radio')
        self.crossfade = tk.DoubleVar(value=50)
        self.visual_style = {d: tk.StringVar(value='Onda real') for d in ('A', 'B')}
        self.visual_intensity = tk.StringVar(value='Normal')
        self.visual_enabled = tk.BooleanVar(value=True)
        self.visual_tick = 0
        self.deck_volume = {'A': tk.DoubleVar(value=75), 'B': tk.DoubleVar(value=75)}
        self.deck_labels = {'A': tk.StringVar(value='Sin canción'), 'B': tk.StringVar(value='Sin canción')}
        self.deck_status = tk.StringVar(value='Tornamesas detenidas')
        self.deck_orientation = tk.StringVar(value='horizontal')
        self.deck_time = {d: tk.StringVar(value='00:00 / 00:00') for d in ('A', 'B')}
        self.deck_artist = {d: tk.StringVar(value='Artista: sin datos') for d in ('A', 'B')}
        self.deck_album = {d: tk.StringVar(value='Álbum: sin datos') for d in ('A', 'B')}
        self.deck_state_label = {d: tk.StringVar(value='LISTO') for d in ('A', 'B')}
        self.deck_vu = {}
        self.deck_vu_peak = {d: 0.0 for d in ('A', 'B')}
        self.deck_wave = {}
        self.deck_progress = {}
        self.deck_cards = {}
        self.bg_audio = None
        self.bg_path = ''
        self.bg_pos = 0
        self.bg_playing = False
        self.bg_volume = tk.DoubleVar(value=25)
        self.bg_loop = tk.BooleanVar(value=True)
        self.bg_restart = tk.BooleanVar(value=True)
        self.bg_duck = tk.BooleanVar(value=True)
        self.bg_speaking_pct = tk.DoubleVar(value=10)
        self.bg_fade_samples = 0
        self.bg_was_blocked = False
        self.pro_mic_status = tk.StringVar(value='MICRÓFONO SILENCIADO • F9')
        self.bg_label = tk.StringVar(value='Sin fondo musical')
        self.bg_status = tk.StringVar(value='Fondo detenido')
        self.audio = None
        self.pos = 0
        self.playing = False
        self.stream = None
        self.devices = []
        self.output_devices = []
        self.output_name = tk.StringVar(value="Predeterminada de Windows")
        self.output_meter_queue = queue.Queue(maxsize=4)
        self.input_meter_queue = queue.Queue(maxsize=4)
        self.input_peak = tk.DoubleVar(value=0)
        # Mediciones reales por canal: el hilo de audio entrega RMS; Tk solo dibuja.
        self.channel_meter_queue = queue.Queue(maxsize=4)
        self.channel_levels = {name: (tk.DoubleVar(value=0), tk.DoubleVar(value=0))
                               for name in ('MIC 1', 'DECK A', 'DECK B', 'FONDO', 'MÚSICA')}
        self.output_left = tk.DoubleVar(value=0)
        self.output_right = tk.DoubleVar(value=0)
        self.recording = False
        self.writer = None
        self.writer_thread = None
        self.write_queue = queue.Queue(maxsize=256)
        self.meter_queue = queue.Queue(maxsize=8)
        self.music_vol = tk.DoubleVar(value=70)
        self.mic_vol = tk.DoubleVar(value=75)
        self.duck = tk.BooleanVar(value=True)
        self.duck_pct = tk.DoubleVar(value=25)
        self.monitor = tk.BooleanVar(value=True)
        self.device_name = tk.StringVar()
        self.status = tk.StringVar(value='Prueba local: sin transmisión a Internet')
        self.meter = tk.DoubleVar(value=0)
        self.rec_status = tk.StringVar(value='Grabación detenida')
        self.duck_factor = 1.0
        self.duck_attack = tk.DoubleVar(value=180)
        self.duck_release = tk.DoubleVar(value=1200)
        self.duck_info = tk.StringVar(value='ESPERANDO AUDIO • Música 100 % del volumen configurado')
        self.duck_meter = tk.DoubleVar(value=100)
        self.duck_events = queue.Queue(maxsize=12)
        self.silence_blocks = 0
        self.talking = False
        self.mic_muted = True  # Inicia silenciado por seguridad.
        self.noise_filter = tk.BooleanVar(value=True)
        self.noise_gate = tk.DoubleVar(value=18)
        self.hp_sos = butter(2, 100, btype='highpass', fs=RATE, output='sos')
        self.hp_state = np.zeros((len(self.hp_sos), 2), dtype='float64')
        self.gate_envelope = 0.0
        self.frames_written = 0
        self.eq_enabled = tk.BooleanVar(value=True)
        self.eq_low = tk.DoubleVar(value=0)
        self.eq_mid = tk.DoubleVar(value=0)
        self.eq_high = tk.DoubleVar(value=0)
        self.compress = tk.BooleanVar(value=False)
        self.echo_pct = tk.DoubleVar(value=0)
        self.eq_states = [None, None, None]
        self.echo_buffer = np.zeros(int(RATE * 0.24), dtype='float32')
        self.echo_index = 0
        self.branding_path = os.path.join(os.path.expanduser('~'), 'CocaBroadcastStudio', 'identidad.json')
        self.logo_path = ''
        self.clock_format = tk.StringVar(value='24')
        self.clock_seconds = tk.BooleanVar(value=True)
        self.clock_zone = tk.StringVar(value='Guatemala (UTC-6)')
        self.branding_save_job = None
        self.profile_path = os.path.join(os.path.expanduser('~'), 'CocaBroadcastStudio', 'perfiles_locutores.json')
        self.active_profile = tk.StringVar(value='Sin perfil')
        self.cart_path = os.path.join(os.path.expanduser('~'), 'CocaBroadcastStudio', 'cart_wall.json')
        self.cart_banks = {'1': [None] * 12, '2': [None] * 12, '3': [None] * 12}
        self.cart_windows = {}
        self.explorer_windows = {}
        self.load_cart_wall()
        self.load_profiles()
        self.load_branding()
        self.aux_console_channels = []  # Canales configurables: interfaz, sin enrutamiento DSP todavía
        self.aux_console_views = []
        self.setup()
        self.root.after(200, self.apply_theme)
        self.detect()
        self.load_default_playlist()
        self.library_init()
        self.library_search()
        self.root.bind('<F9>', self.toggle_mute)
        self.root.after(100, self.refresh)
        root.protocol('WM_DELETE_WINDOW', self.close)

    def load_branding(self):
        try:
            with open(self.branding_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
            if isinstance(data.get('name'), str):
                self.station_name.set(data['name'][:80] or 'Coca Radio')
            self.logo_path = data.get('logo', '')
            self.station_slogan.set(data.get('slogan', self.station_slogan.get()))
            self.clock_format.set(data.get('format', '24') if data.get('format') in ('12', '24') else '24')
            self.clock_seconds.set(bool(data.get('seconds', True)))
            self.clock_zone.set(data.get('zone', 'Guatemala (UTC-6)'))
        except (OSError, ValueError, TypeError):
            pass

    def save_branding(self):
        self.branding_save_job = None
        try:
            os.makedirs(os.path.dirname(self.branding_path), exist_ok=True)
            data = {'name': self.station_name.get(), 'slogan': self.station_slogan.get(), 'logo': self.logo_path,
                    'format': self.clock_format.get(), 'seconds': self.clock_seconds.get(),
                    'zone': self.clock_zone.get()}
            tmp = self.branding_path + '.tmp'
            with open(tmp, 'w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
            os.replace(tmp, self.branding_path)
        except OSError as exc:
            messagebox.showwarning('Configuración', f'No se pudo guardar la identidad: {exc}')

    def schedule_branding_save(self):
        if self.branding_save_job is not None:
            self.root.after_cancel(self.branding_save_job)
        self.branding_save_job = self.root.after(450, self.save_branding)

    def update_brand_logo(self):
        self.brand_logo_image = None
        if self.logo_path and os.path.isfile(self.logo_path):
            try:
                from PIL import Image, ImageTk
                with Image.open(self.logo_path) as im:
                    im.thumbnail((82, 68))
                    self.brand_logo_image = ImageTk.PhotoImage(im.convert('RGBA'))
            except ImportError:
                try:
                    self.brand_logo_image = tk.PhotoImage(file=self.logo_path)
                    if self.brand_logo_image.width() > 82 or self.brand_logo_image.height() > 68:
                        factor = max(1, math.ceil(max(self.brand_logo_image.width()/82, self.brand_logo_image.height()/68)))
                        self.brand_logo_image = self.brand_logo_image.subsample(factor, factor)
                except tk.TclError:
                    pass
            except (OSError, ValueError):
                pass
        if self.brand_logo_image is not None:
            self.logo_label.configure(image=self.brand_logo_image, text='', width=82, height=68)
        else:
            self.logo_label.configure(image='', text='RADIO', width=9, height=4, font=('Segoe UI', 10, 'bold'))

    def choose_brand_logo(self):
        path = filedialog.askopenfilename(title='Seleccionar logo de la emisora',
                    filetypes=[('Imágenes', '*.png *.jpg *.jpeg *.gif'), ('Todos los archivos', '*.*')])
        if not path:
            return
        try:
            os.makedirs(os.path.dirname(self.branding_path), exist_ok=True)
            ext = os.path.splitext(path)[1].lower()
            dest = os.path.join(os.path.dirname(self.branding_path), 'logo_emisora' + ext)
            if os.path.abspath(path) != os.path.abspath(dest):
                shutil.copy2(path, dest)
            self.logo_path = dest
            self.update_brand_logo()
            self.schedule_branding_save()
            if self.brand_logo_image is None:
                messagebox.showinfo('Logo', 'Para visualizar JPG o redimensionar imágenes instala Pillow:\npy -3.13 -m pip install pillow')
        except OSError as exc:
            messagebox.showerror('Logo', str(exc))

    def update_brand_clock(self):
        zone = self.clock_zone.get()
        if zone == 'Guatemala (UTC-6)':
            now = datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=-6)))
        elif zone == 'UTC':
            now = datetime.datetime.now(datetime.timezone.utc)
        else:
            now = datetime.datetime.now().astimezone()
        pattern = '%I:%M:%S %p' if self.clock_format.get() == '12' else '%H:%M:%S'
        if not self.clock_seconds.get():
            pattern = pattern.replace(':%S', '')
        self.clock_label.configure(text=now.strftime(pattern).lstrip('0'))
        days = ('lunes', 'martes', 'miércoles', 'jueves', 'viernes', 'sábado', 'domingo')
        months = ('enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre')
        self.date_label.configure(text=f'{days[now.weekday()].capitalize()}, {now.day} de {months[now.month-1]} de {now.year}  •  {zone}')
        self.root.after(250, self.update_brand_clock)

    def branding_dialog(self):
        win = tk.Toplevel(self.root)
        win.title('Identidad de emisora y reloj')
        win.configure(bg=BG)
        win.geometry('490x410')
        win.resizable(False, False)
        win.transient(self.root)
        tk.Label(win, text='IDENTIDAD DE LA EMISORA', bg=BG, fg='#48c9ff', font=('Segoe UI', 14, 'bold')).pack(pady=(15, 8))
        ttk.Label(win, text='Nombre de la emisora:').pack(anchor='w', padx=24)
        ttk.Entry(win, textvariable=self.station_name, width=47).pack(fill='x', padx=24, pady=(2, 6))
        ttk.Label(win, text='Eslogan (editable para cada emisora):').pack(anchor='w', padx=24)
        ttk.Entry(win, textvariable=self.station_slogan, width=47).pack(fill='x', padx=24, pady=(2, 10))
        ttk.Button(win, text='Seleccionar logo PNG/JPG', command=self.choose_brand_logo).pack(anchor='w', padx=24)
        ttk.Label(win, text='Formato del reloj:').pack(anchor='w', padx=24, pady=(12, 2))
        options = ttk.Frame(win)
        options.pack(anchor='w', padx=24)
        ttk.Radiobutton(options, text='24 horas', variable=self.clock_format, value='24').pack(side='left', padx=(0, 15))
        ttk.Radiobutton(options, text='12 horas', variable=self.clock_format, value='12').pack(side='left')
        ttk.Checkbutton(win, text='Mostrar segundos', variable=self.clock_seconds).pack(anchor='w', padx=24, pady=6)
        zones = ('Guatemala (UTC-6)', 'Hora local del equipo', 'UTC')
        ttk.Combobox(win, textvariable=self.clock_zone, values=zones, state='readonly', width=28).pack(anchor='w', padx=24)
        def finish():
            self.save_branding()
            win.destroy()
        ttk.Button(win, text='Guardar y cerrar', command=finish).pack(pady=12)
        win.protocol('WM_DELETE_WINDOW', finish)

    def setup(self):
        style = ttk.Style()
        style.theme_use('clam')
        style.configure('TFrame', background=BG)
        style.configure('TLabel', background=BG, foreground='#e6f4ff', font=('Segoe UI', 10))
        style.configure('TButton', font=('Segoe UI', 10), padding=7)
        style.configure('TCheckbutton', background=BG, foreground='white')
        style.map('TCheckbutton', background=[('active', BG)], foreground=[('active', 'white')])
        style.configure('Horizontal.TProgressbar', troughcolor='#102847', background='#48c9ff')
        style.configure('TNotebook', background=BG)
        style.configure('TNotebook.Tab', padding=(22, 9), font=('Segoe UI', 10, 'bold'))
        header = tk.Frame(self.root, bg=BG)
        header.pack(fill='x', padx=18, pady=(7, 2))
        left = tk.Frame(header, bg=BG)
        left.pack(side='left', fill='y')
        self.logo_label = tk.Label(left, text='📻', bg='#102847', fg='#48c9ff', font=('Segoe UI', 25), width=4, height=2, cursor='hand2')
        self.logo_label.pack(side='left', padx=(0, 12))
        self.logo_label.bind('<Button-1>', lambda event: self.branding_dialog())
        heading = tk.Frame(left, bg=BG)
        heading.pack(side='left', anchor='center')
        tk.Label(heading, text='COCA BROADCAST STUDIO', bg=BG, fg='#48c9ff', font=('Segoe UI', 20, 'bold')).pack(anchor='w')
        tk.Label(heading, textvariable=self.station_name, bg=BG, fg='white', font=('Segoe UI', 11, 'bold')).pack(anchor='w')
        tk.Label(heading, textvariable=self.station_slogan, bg=BG, fg='#a3c4e5', font=('Segoe UI', 9), wraplength=480, justify='left').pack(anchor='w')
        clock = tk.Frame(header, bg=BG)
        clock.pack(side='right', anchor='n')
        self.clock_label = tk.Label(clock, bg=BG, fg='white', font=('Consolas', 19, 'bold'))
        self.clock_label.pack(anchor='e')
        self.date_label = tk.Label(clock, bg=BG, fg='#a3c4e5', font=('Segoe UI', 9))
        self.date_label.pack(anchor='e')
        ttk.Button(clock, text='⚙ Emisora / reloj', command=self.branding_dialog).pack(anchor='e', pady=(2, 0))
        self.update_brand_logo()
        self.update_brand_clock()
        self.station_name.trace_add('write', lambda *_: self.schedule_branding_save())
        self.station_slogan.trace_add('write', lambda *_: self.schedule_branding_save())
        tk.Label(self.root, text='Versión 1.0.3-R8a • Corrección de inicio • Consola digital integrada • Explorador • Cart Wall • Temas • Cabina unificada • Menú lateral • Paneles flotantes • Eslogan • Logo y reloj • Scroll adaptable • Radio/DJ • 8 visualizadores • Crossfader • Ondas • Auto Ducking • Biblioteca • AutoDJ • Jingles • WAV', bg=BG, fg='#a3c4e5', font=('Segoe UI', 8)).pack()
        # Navegación lateral. La barra de pestañas se oculta; el contenido original se conserva.
        style.layout('Side.TNotebook.Tab', [])
        style.configure('Side.TNotebook', background=BG, borderwidth=0)
        workspace = ttk.Frame(self.root)
        workspace.pack(fill='both', expand=True, padx=12, pady=9)
        self.side_menu = tk.Frame(workspace, bg='#102847', width=185)
        self.side_menu.pack(side='left', fill='y', padx=(0, 7))
        self.side_menu.pack_propagate(False)
        self.side_visible = True
        self.menu_buttons = []
        self.sidebar_canvas = tk.Canvas(self.side_menu, bg='#102847', highlightthickness=0, borderwidth=0)
        self.sidebar_scroll = ttk.Scrollbar(self.side_menu, orient='vertical', command=self.sidebar_canvas.yview)
        self.sidebar_canvas.configure(yscrollcommand=self.sidebar_scroll.set)
        self.sidebar_scroll.pack(side='right', fill='y')
        self.sidebar_canvas.pack(side='left', fill='both', expand=True)
        sidebar_content = tk.Frame(self.sidebar_canvas, bg='#102847')
        sidebar_window = self.sidebar_canvas.create_window((0, 0), window=sidebar_content, anchor='nw')
        sidebar_content.bind('<Configure>', lambda e: self.sidebar_canvas.configure(scrollregion=self.sidebar_canvas.bbox('all')))
        self.sidebar_canvas.bind('<Configure>', lambda e: self.sidebar_canvas.itemconfigure(sidebar_window, width=e.width))
        self.sidebar_canvas.bind('<MouseWheel>', lambda e: self.sidebar_canvas.yview_scroll(-int(e.delta/120), 'units'))
        tk.Button(sidebar_content, text='☰  OCULTAR MENÚ', command=self.toggle_sidebar,
                  bg='#164567', fg='white', relief='flat').pack(fill='x', padx=7, pady=8)
        main = ttk.Frame(workspace)
        main.pack(side='left', fill='both', expand=True)
        tk.Button(main, text='☰', command=self.toggle_sidebar, bg='#164567', fg='white',
                  relief='flat', width=3).pack(anchor='w')
        tabs = ttk.Notebook(main, style='Side.TNotebook')
        tabs.pack(fill='both', expand=True)
        self.main_tabs = tabs

        cabina, mezclador, efectos = ttk.Frame(tabs), ttk.Frame(tabs), ttk.Frame(tabs)
        tabs.add(cabina, text='CABINA')
        tabs.add(mezclador, text='MEZCLADOR')
        tabs.add(efectos, text='EFECTOS DE VOZ')
        digital = ttk.Frame(tabs)
        tabs.add(digital, text='CONSOLA DIGITAL')
        # Contenido desplazable para las tres secciones sin alterar los controles originales.
        cabina = self.scrollable_panel(cabina, 'cabina')
        mezclador = self.scrollable_panel(mezclador, 'mezclador')
        efectos = self.scrollable_panel(efectos, 'efectos')
        # Los selectores deben existir antes de construir la consola digital.
        self.modular_mic_combos = []
        self.build_digital_console(digital)
        horario = ttk.Frame(tabs)
        tabs.add(horario, text='LOCUCIÓN HORARIA')
        jingles = ttk.Frame(tabs)
        tabs.add(jingles, text='JINGLES')
        biblioteca = ttk.Frame(tabs)
        tabs.add(biblioteca, text='BIBLIOTECA')
        unified = ttk.Frame(tabs)
        tabs.add(unified, text='CABINA PROFESIONAL')
        legacy_decks = ttk.Frame(tabs)
        tabs.add(legacy_decks, text='MOTOR VISUAL')
        self.setup_decks(legacy_decks)
        self.unified_deck_wave = {}
        self.unified_deck_progress = {}
        self.setup_unified(unified)
        for idx, label in enumerate(('🎙  Cabina', '🎚  Mezclador', '🎛  Efectos de voz',
                                      '🕒  Locución horaria', '🔊  Jingles', '🎵  Biblioteca',
                                      '🎧  Cabina profesional')):
            btn = tk.Button(sidebar_content, text=label, anchor='w', bg='#102847', fg='white',
                            activebackground='#15517b', activeforeground='white', relief='flat',
                            command=lambda i=idx: self.main_tabs.select(i if i < 3 else i + 1))
            btn.pack(fill='x', padx=7, pady=3, ipady=7)
            self.menu_buttons.append(btn)
        tk.Button(sidebar_content, text='🎛  CONSOLA DIGITAL', anchor='w', bg='#15517b', fg='white', relief='flat', command=lambda: self.main_tabs.select(3)).pack(fill='x', padx=7, pady=4, ipady=8)
        tk.Button(sidebar_content, text='👤  PERFILES LOCUTORES', anchor='w', bg='#126079', fg='white',
                  relief='flat', command=self.profiles_dialog).pack(fill='x', padx=7, pady=(12, 3), ipady=8)
        tk.Button(sidebar_content, text='🎨  APARIENCIA Y TEMAS', anchor='w', bg='#126079', fg='white',
                  relief='flat', command=self.theme_dialog).pack(fill='x', padx=7, pady=3, ipady=8)
        tk.Button(sidebar_content, text='📁  EXPLORADOR MUSICAL', anchor='w', bg='#126079', fg='white',
                  relief='flat', command=self.open_music_explorer).pack(fill='x', padx=7, pady=3, ipady=8)
        tk.Button(sidebar_content, text='🎛  CART WALL', anchor='w', bg='#126079', fg='white',
                  relief='flat', command=self.open_cart_wall).pack(fill='x', padx=7, pady=3, ipady=8)
        tk.Button(sidebar_content, text='▣  Paneles flotantes', anchor='w', bg='#15517b', fg='white',
                  relief='flat', command=self.open_floating_controls).pack(fill='x', padx=7, pady=10, ipady=7)
        tk.Button(sidebar_content, text='⚙  Emisora / reloj', anchor='w', bg='#102847', fg='white',
                  relief='flat', command=self.branding_dialog).pack(fill='x', padx=7, pady=3, ipady=7)
        tabs.bind('<<NotebookTabChanged>>', self.highlight_sidebar)
        self.highlight_sidebar()

        ttk.Label(biblioteca, text='BIBLIOTECA MUSICAL • BÚSQUEDA LOCAL').pack(anchor='w', padx=18, pady=(15, 7))
        actions = ttk.Frame(biblioteca)
        actions.pack(fill='x', padx=18, pady=4)
        ttk.Button(actions, text='Importar carpeta y subcarpetas', command=self.library_choose_folder).pack(side='left', padx=(0, 7))
        ttk.Button(actions, text='Actualizar biblioteca', command=self.library_rescan).pack(side='left', padx=7)
        ttk.Button(actions, text='Carpetas registradas', command=self.library_show_folders).pack(side='left', padx=7)
        ttk.Label(biblioteca, text='Buscar por nombre de canción o carpeta:').pack(anchor='w', padx=18, pady=(10, 3))
        searchrow = ttk.Frame(biblioteca)
        searchrow.pack(fill='x', padx=18)
        ttk.Entry(searchrow, textvariable=self.library_query).pack(side='left', fill='x', expand=True)
        ttk.Button(searchrow, text='Limpiar', command=lambda: self.library_query.set('')).pack(side='left', padx=6)
        self.library_query.trace_add('write', self.library_schedule_search)
        self.library_listbox = tk.Listbox(biblioteca, bg='#102847', fg='white', selectbackground='#1275c5', selectmode='extended', height=12)
        self.library_listbox.pack(fill='both', expand=True, padx=18, pady=9)
        self.library_listbox.bind('<Double-Button-1>', lambda e: self.library_add_selected())
        self.library_results = []
        bottom = ttk.Frame(biblioteca)
        bottom.pack(fill='x', padx=18, pady=4)
        ttk.Button(bottom, text='Añadir seleccionadas a CABINA', command=self.library_add_selected).pack(side='left', padx=(0, 8))
        ttk.Button(bottom, text='Añadir resultados visibles', command=self.library_add_visible).pack(side='left', padx=8)
        ttk.Label(biblioteca, textvariable=self.library_status, wraplength=920).pack(anchor='w', padx=18, pady=(10, 5))
        ttk.Label(biblioteca, text='Los audios NO se copian. Si desconectas el USB, aparecerán como no disponibles hasta reconectarlo. La búsqueda muestra hasta 500 resultados.', wraplength=900).pack(anchor='w', padx=18, pady=5)
        ttk.Label(jingles, text='IDENTIFICACIONES Y JINGLES DE LA EMISORA').pack(anchor='w', padx=20, pady=(20, 10))
        ttk.Button(jingles, text='Importar carpeta de jingles MP3/WAV', command=self.import_jingles).pack(anchor='w', padx=20, pady=6)
        self.jingle_listbox = tk.Listbox(jingles, bg='#102847', fg='white', selectbackground='#1275c5', height=9)
        self.jingle_listbox.pack(fill='both', expand=True, padx=20, pady=5)
        ttk.Button(jingles, text='Reproducir jingle manualmente', command=self.play_jingle_manual).pack(anchor='w', padx=20, pady=6)
        ttk.Checkbutton(jingles, text='Insertar jingle automáticamente entre canciones', variable=self.jingle_auto).pack(anchor='w', padx=20, pady=6)
        freqrow = ttk.Frame(jingles)
        freqrow.pack(anchor='w', padx=20, pady=5)
        ttk.Label(freqrow, text='Cada').pack(side='left')
        ttk.Combobox(freqrow, textvariable=self.jingle_every, values=['1', '2', '3', '5', '10'], width=5, state='readonly').pack(side='left', padx=8)
        ttk.Label(freqrow, text='canciones completas').pack(side='left')
        self.numeric_scale(jingles, 'Volumen del jingle', self.jingle_volume, 0, 100, ' %')
        ttk.Label(jingles, textvariable=self.jingle_status, wraplength=800).pack(anchor='w', padx=20, pady=8)
        ttk.Label(jingles, text='En modo automático, el jingle se reproduce entre canciones. El botón manual lo superpone a la música.', wraplength=800).pack(anchor='w', padx=20, pady=6)
        ttk.Label(horario, text='ANUNCIOS AUTOMÁTICOS DE LA HORA').pack(anchor='w', padx=20, pady=(22, 12))
        ttk.Checkbutton(horario, text='Activar locución horaria', variable=self.hour_enabled, command=self.reset_hour_schedule).pack(anchor='w', padx=20, pady=6)
        line = ttk.Frame(horario)
        line.pack(anchor='w', padx=20, pady=8)
        ttk.Label(line, text='Intervalo:').pack(side='left', padx=(0, 10))
        ttk.Combobox(line, textvariable=self.hour_interval, values=['15', '30', '60'], state='readonly', width=8).pack(side='left')
        ttk.Label(line, text='minutos').pack(side='left', padx=8)
        ttk.Label(horario, text='Nombre de la emisora:').pack(anchor='w', padx=20, pady=(12, 4))
        ttk.Entry(horario, textvariable=self.station_name, width=45).pack(anchor='w', padx=20)
        ttk.Label(horario, text='Origen de la locución:').pack(anchor='w', padx=20, pady=(14, 3))
        ttk.Radiobutton(horario, text='Voz de Windows (original)', variable=self.hour_source, value='windows').pack(anchor='w', padx=20)
        ttk.Radiobutton(horario, text='Mis grabaciones MP3/WAV (respaldo: Windows)', variable=self.hour_source, value='files').pack(anchor='w', padx=20)
        ttk.Button(horario, text='Elegir carpeta de locuciones', command=self.choose_hour_folder).pack(anchor='w', padx=20, pady=7)
        ttk.Label(horario, textvariable=self.hour_folder, wraplength=760).pack(anchor='w', padx=20)
        ttk.Label(horario, text='Archivos: HH-MM.mp3 o HH-MM.wav en formato 24 horas; ejemplo 09-15.mp3', wraplength=760).pack(anchor='w', padx=20, pady=4)
        ttk.Button(horario, text='Probar locución ahora', command=self.test_hour).pack(anchor='w', padx=20, pady=(20, 10))
        ttk.Label(horario, textvariable=self.hour_status, wraplength=650).pack(anchor='w', padx=20, pady=8)
        ttk.Label(horario, text='La voz se genera localmente con Windows. La música baja durante el anuncio.\nRequiere Windows PowerShell 5.1 y una voz de español instalada.', wraplength=700).pack(anchor='w', padx=20, pady=8)
        self.hour_interval.trace_add('write', lambda *_: self.reset_hour_schedule())
        ttk.Label(cabina, text='LISTA DE MÚSICA').pack(anchor='w', padx=12, pady=(12, 4))
        self.listbox = tk.Listbox(cabina, bg='#102847', fg='white', selectbackground='#1275c5', height=6)
        self.listbox.pack(fill='both', expand=True, padx=12)
        self.listbox.bind('<Double-Button-1>', lambda e: self.play())
        row = ttk.Frame(cabina)
        row.pack(anchor='w', padx=12, pady=7)
        for label, fn in [('Añadir MP3/WAV', self.add), ('Importar carpeta', self.add_folder), ('Reproducir', self.play), ('Pausar', self.pause), ('Detener', self.stop)]:
            ttk.Button(row, text=label, command=fn).pack(side='left', padx=3)
        auto_row = ttk.Frame(cabina)
        auto_row.pack(anchor='w', padx=12, pady=(2, 6))
        self.mode_button = tk.Button(auto_row, text='MODO MANUAL', command=self.toggle_mode, bg='#b36b28', fg='white', font=('Segoe UI', 10, 'bold'), padx=12, pady=6)
        self.mode_button.pack(side='left', padx=(0, 8))
        ttk.Checkbutton(auto_row, text='Orden aleatorio', variable=self.shuffle_mode).pack(side='left', padx=5)
        ttk.Button(auto_row, text='Siguiente canción', command=self.next_track).pack(side='left', padx=5)
        playlist_row = ttk.Frame(cabina)
        playlist_row.pack(anchor='w', padx=12, pady=(0, 4))
        ttk.Button(playlist_row, text='Guardar lista', command=self.save_playlist).pack(side='left', padx=3)
        ttk.Button(playlist_row, text='Guardar lista como...', command=self.save_playlist_as).pack(side='left', padx=3)
        ttk.Button(playlist_row, text='Cargar lista', command=self.load_playlist_dialog).pack(side='left', padx=3)
        ttk.Button(playlist_row, text='Quitar seleccionada', command=self.remove_selected).pack(side='left', padx=3)
        ttk.Label(cabina, text='MICRÓFONO').pack(anchor='w', padx=12, pady=(8, 3))
        self.combo = ttk.Combobox(cabina, textvariable=self.device_name, state='readonly', width=48)
        self.combo.pack(anchor='w', padx=12)
        microw = ttk.Frame(cabina)
        microw.pack(anchor='w', padx=12, pady=6)
        for label, fn in [('Actualizar entradas', self.detect), ('Iniciar audio', self.start_audio), ('Detener audio', self.stop_audio)]:
            ttk.Button(microw, text=label, command=fn).pack(side='left', padx=3)
        self.mute_button = tk.Button(cabina, text='MICRÓFONO SILENCIADO  •  F9', bg='#b33644', fg='white', font=('Segoe UI', 11, 'bold'), relief='flat', padx=12, pady=9, command=self.toggle_mute)
        self.mute_button.pack(anchor='w', fill='x', padx=12, pady=3)
        self.mute_label = ttk.Label(cabina, text='La voz NO entra en la mezcla ni en la grabación.')
        self.mute_label.pack(anchor='w', padx=12)
        ttk.Progressbar(cabina, variable=self.meter, maximum=100, length=330).pack(anchor='w', padx=12, pady=6)
        ttk.Label(cabina, text='GRABACIÓN LOCAL WAV').pack(anchor='w', padx=12, pady=(8, 3))
        recrow = ttk.Frame(cabina)
        recrow.pack(anchor='w', padx=12)
        ttk.Button(recrow, text='Grabar mezcla', command=self.start_record).pack(side='left', padx=(0, 5))
        ttk.Button(recrow, text='Detener grabación', command=self.stop_record).pack(side='left')
        ttk.Label(cabina, textvariable=self.rec_status).pack(anchor='w', padx=12, pady=4)
        self.console_section_title(mezclador, 'MEZCLADOR DIGITAL • CONTROLES DEL MOTOR ORIGINAL')
        self.console_fader(mezclador, self.music_vol, 'MÚSICA • FADER Y PERILLA')
        self.console_fader(mezclador, self.mic_vol, 'MICRÓFONO • FADER Y PERILLA')
        ttk.Label(mezclador, text='MEZCLADOR DE AUDIO').pack(anchor='w', padx=20, pady=(18, 8))
        # Los faders superiores son los controles únicos de volumen.
        ttk.Checkbutton(mezclador, text='Auto Ducking', variable=self.duck).pack(anchor='w', padx=20, pady=10)
        self.scale(mezclador, 'Música mientras hablas (%)', self.duck_pct)
        ttk.Label(mezclador, text='TRANSICIONES DEL AUTO DUCKING').pack(anchor='w', padx=20, pady=(18, 2))
        self.numeric_scale(mezclador, 'Bajada al hablar', self.duck_attack, 50, 1000, ' ms')
        self.numeric_scale(mezclador, 'Recuperación al callar', self.duck_release, 200, 4000, ' ms')
        ttk.Label(mezclador, textvariable=self.duck_info, font=('Segoe UI', 11, 'bold')).pack(anchor='w', padx=20, pady=(20, 6))
        ttk.Progressbar(mezclador, variable=self.duck_meter, maximum=100, length=350).pack(anchor='w', padx=20)
        ttk.Label(mezclador, text='Indicador: 100 % = música normal; 20 % = música reducida.', wraplength=550).pack(anchor='w', padx=20, pady=8)
        ttk.Checkbutton(mezclador, text='Escuchar mi voz (usar audífonos)', variable=self.monitor).pack(anchor='w', padx=20, pady=12)
        self.console_section_title(efectos, 'EFECTOS DE VOZ • PANEL DIGITAL')
        ttk.Label(efectos, text='PROCESAMIENTO DE VOZ').pack(anchor='w', padx=20, pady=(15, 7))
        ttk.Checkbutton(efectos, text='Filtro de ruido activado', variable=self.noise_filter).pack(anchor='w', padx=20)
        self.scale(efectos, 'Intensidad de puerta de ruido (%)', self.noise_gate)
        ttk.Checkbutton(efectos, text='Ecualizador activado', variable=self.eq_enabled).pack(anchor='w', padx=20, pady=(12, 3))
        for label, variable in [('Graves (0 = neutro)', self.eq_low), ('Medios (0 = neutro)', self.eq_mid), ('Agudos (0 = neutro)', self.eq_high)]:
            self.eq_scale(efectos, label, variable)
        ttk.Checkbutton(efectos, text='Compresión suave de voz', variable=self.compress).pack(anchor='w', padx=20, pady=(12, 3))
        self.scale(efectos, 'Eco de voz (%)', self.echo_pct)
        ttk.Button(efectos, text='Restablecer efectos', command=self.reset_effects).pack(anchor='w', padx=20, pady=(12, 3))
        ttk.Label(efectos, text='Empieza con ecualizador neutro y eco al 0 %. Usa audífonos.', wraplength=500).pack(anchor='w', padx=20, pady=8)
        tk.Label(self.root, textvariable=self.status, bg='#0e2848', fg='#cbeeff', anchor='w', padx=15, pady=10).pack(fill='x', side='bottom')

    def load_theme_settings(self):
        try:
            with open(self.theme_path, encoding='utf-8') as f:
                name = json.load(f).get('theme')
            if name in THEMES:
                self.theme_name.set(name)
        except (OSError, ValueError, TypeError, AttributeError):
            pass

    def apply_theme(self, name=None):
        global BG
        if name in THEMES:
            self.theme_name.set(name)
        name = self.theme_name.get()
        bg, panel, accent = THEMES.get(name, THEMES['Azul profesional'])
        BG = bg
        self.root.configure(bg=bg)
        style = ttk.Style(self.root)
        style.configure('TFrame', background=bg)
        style.configure('TLabel', background=bg, foreground='#f0f5fa')
        style.configure('TLabelframe', background=bg, bordercolor=accent)
        style.configure('TLabelframe.Label', background=bg, foreground=accent, font=('Segoe UI', 10, 'bold'))
        style.configure('TButton', background=panel, foreground='#ffffff', padding=(13, 10), font=('Segoe UI', 10, 'bold'), relief='raised', borderwidth=2)
        style.map('TButton', background=[('active', accent), ('pressed', accent)], foreground=[('active', '#10151c')])
        for sty, col in [('Play.TButton','#167b4a'),('Pause.TButton','#a87914'),('Stop.TButton','#a52e3e'),('Mic.TButton','#1769a7'),('Cue.TButton','#175f9b'),('Action.TButton',panel)]:
            style.configure(sty, background=col, foreground='white', padding=(13,10), font=('Segoe UI', 10, 'bold'), relief='raised', borderwidth=2)
            style.map(sty, background=[('active', accent)])
        style.configure('TCheckbutton', background=bg, foreground='white')
        style.map('TCheckbutton', background=[('active', bg)], foreground=[('active','white')])
        style.configure('TRadiobutton', background=bg, foreground='white')
        style.map('TRadiobutton', background=[('active',bg)], foreground=[('active','white')])
        style.configure('Horizontal.TProgressbar', background=accent, troughcolor=panel)
        style.configure('Horizontal.TScale', background=bg, troughcolor=panel)
        style.configure('TNotebook', background=bg)
        style.configure('TNotebook.Tab', background=panel, foreground='white')
        style.configure('TCombobox', fieldbackground=panel, background=panel, foreground='white')
        style.map('TCombobox', fieldbackground=[('readonly',panel)], foreground=[('readonly','white')])
        style.configure('TEntry', fieldbackground=panel, foreground='white')
        self.root.option_add('*TCombobox*Listbox.background', panel)
        self.root.option_add('*TCombobox*Listbox.foreground', 'white')
        def recolor(widget):
            if isinstance(widget, (tk.Frame, tk.LabelFrame)):
                try: widget.configure(bg=bg)
                except tk.TclError: pass
            elif isinstance(widget, tk.Label):
                try:
                    old_bg = widget.cget('bg').lower()
                    if old_bg not in ('white', '#ffffff', '#f0f0f0'):
                        widget.configure(bg=bg)
                    old_fg = widget.cget('fg').lower()
                    if old_fg in ('#48c9ff', '#00d8ff', '#32cfff'):
                        widget.configure(fg=accent)
                except tk.TclError: pass
            elif isinstance(widget, tk.Button):
                try:
                    label=widget.cget('text').lower()
                    color = '#167b4a' if ('▶' in label or 'reproducir' in label or 'iniciar audio' in label or label.strip() == 'on') else ('#a87914' if ('pausar' in label or 'Ⅱ' in label or 'cue' in label) else ('#a52e3e' if ('detener' in label or '■' in label or 'mute' in label or 'silencio' in label) else ('#1769a7' if ('micrófono' in label or 'f9' in label) else panel)))
                    widget.configure(bg=color, fg='white', activebackground=accent, activeforeground='#10151c', relief='raised', bd=2, padx=10, pady=8, cursor='hand2')
                except tk.TclError: pass
            elif isinstance(widget, ttk.Button):
                try:
                    label = widget.cget('text').lower()
                    if 'reproducir' in label or 'iniciar audio' in label or label.strip() in ('▶', '▷', '▸'):
                        widget.configure(style='Play.TButton')
                    elif 'pausar' in label or label.strip() in ('Ⅱ', '⏸'):
                        widget.configure(style='Pause.TButton')
                    elif 'detener' in label or label.strip() in ('■', '⏹'):
                        widget.configure(style='Stop.TButton')
                    elif 'micrófono' in label or 'f9' in label:
                        widget.configure(style='Mic.TButton')
                    elif 'cue' in label or 'previa' in label:
                        widget.configure(style='Cue.TButton')
                    else:
                        widget.configure(style='Action.TButton')
                except tk.TclError: pass
            elif isinstance(widget, tk.Listbox):
                try: widget.configure(bg=panel, fg='white', selectbackground=accent, selectforeground='#111111')
                except tk.TclError: pass
            for child in widget.winfo_children():
                recolor(child)
        recolor(self.root)
        try:
            os.makedirs(os.path.dirname(self.theme_path), exist_ok=True)
            tmp = self.theme_path + '.tmp'
            with open(tmp, 'w', encoding='utf-8') as f:
                json.dump({'theme':name}, f, ensure_ascii=False, indent=2)
            os.replace(tmp, self.theme_path)
        except OSError:
            pass

    def theme_dialog(self):
        win = tk.Toplevel(self.root)
        win.title('Apariencia y temas • Coca Broadcast Studio')
        win.geometry('510x510')
        win.minsize(420, 430)
        win.configure(bg=THEMES[self.theme_name.get()][0])
        ttk.Label(win, text='APARIENCIA Y TEMAS', font=('Segoe UI', 16, 'bold')).pack(pady=(18, 5))
        ttk.Label(win, text='Elige un tema. Los cambios se aplican sin reiniciar.').pack(pady=5)
        selection = tk.StringVar(value=self.theme_name.get())
        for name, (bg, panel, accent) in THEMES.items():
            row = tk.Frame(win, bg=panel, height=48)
            row.pack(fill='x', padx=20, pady=4)
            tk.Radiobutton(row, text=name, variable=selection, value=name, command=lambda n=name: self.apply_theme(n),
                           bg=panel, fg='white', activebackground=panel, activeforeground='white',
                           selectcolor=bg, font=('Segoe UI', 11, 'bold')).pack(side='left', padx=12, pady=7)
            tk.Label(row, text='●  ●  ●', bg=panel, fg=accent, font=('Segoe UI', 15, 'bold')).pack(side='right', padx=12)
        ttk.Label(win, text='Al guardar un perfil, también se guardará el tema actual.').pack(pady=9)
        ttk.Button(win, text='Restaurar azul profesional', command=lambda: (selection.set('Azul profesional'), self.apply_theme('Azul profesional'))).pack(pady=4)
        ttk.Button(win, text='Cerrar', command=win.destroy).pack(pady=5)

    def decode_local_audio(self, path):
        data, rate = sf.read(path, dtype='float32', always_2d=True)
        if rate != RATE:
            divisor = math.gcd(rate, RATE)
            data = resample_poly(data, RATE // divisor, rate // divisor, axis=0).astype('float32')
        if data.shape[1] == 1:
            data = np.repeat(data, 2, axis=1)
        return np.ascontiguousarray(data[:, :2], dtype='float32')

    def toggle_sidebar(self):
        if self.side_visible:
            self.side_menu.pack_forget()
        else:
            self.side_menu.pack(side='left', fill='y', before=self.main_tabs.master, padx=(0, 7))
        self.side_visible = not self.side_visible

    def highlight_sidebar(self, event=None):
        selected = self.main_tabs.index(self.main_tabs.select())
        for idx, button in enumerate(self.menu_buttons):
            button.configure(bg='#15517b' if (idx if idx < 3 else idx + 1) == selected else '#102847')

    # Explorador y Cart Wall: ventanas independientes, sin reiniciar el motor de audio.
    def load_cart_wall(self):
        try:
            with open(self.cart_path, encoding='utf-8') as handle:
                data = json.load(handle)
            for bank in self.cart_banks:
                values = data.get(bank, [])
                if isinstance(values, list):
                    self.cart_banks[bank] = [v if isinstance(v, dict) and
                        isinstance(v.get('path'), str) else None for v in values[:12]]
                    self.cart_banks[bank] += [None] * (12 - len(self.cart_banks[bank]))
        except (OSError, ValueError, TypeError):
            pass

    def save_cart_wall(self):
        try:
            os.makedirs(os.path.dirname(self.cart_path), exist_ok=True)
            with open(self.cart_path, 'w', encoding='utf-8') as handle:
                json.dump(self.cart_banks, handle, ensure_ascii=False, indent=2)
        except OSError as exc:
            messagebox.showerror('Cart Wall', 'No se pudo guardar: ' + str(exc))

    def open_music_explorer(self):
        if self.explorer_windows:
            win = next(iter(self.explorer_windows.values()))
            if win.winfo_exists():
                win.lift()
                return
        win = tk.Toplevel(self.root)
        self.explorer_windows['main'] = win
        win.title('Coca Broadcast Studio • Explorador musical')
        win.geometry('700x570')
        win.minsize(470, 350)
        def on_close():
            self.explorer_windows.pop('main', None)
            win.destroy()
        win.protocol('WM_DELETE_WINDOW', on_close)
        ttk.Label(win, text='EXPLORADOR MUSICAL • MP3 / WAV', font=('Segoe UI', 12, 'bold')).pack(anchor='w', padx=12, pady=8)
        ttk.Label(win, text='Selecciona una carpeta y luego un archivo. Los originales no se modifican.').pack(anchor='w', padx=12)
        top = ttk.Frame(win)
        top.pack(fill='x', padx=12, pady=8)
        path_var = tk.StringVar(value=os.path.expanduser('~'))
        ttk.Entry(top, textvariable=path_var).pack(side='left', fill='x', expand=True)
        tree = ttk.Treeview(win, columns=('type',), show='tree', selectmode='browse')
        tree.pack(fill='both', expand=True, padx=12, pady=4)
        status = tk.StringVar(value='Abre una carpeta para mostrar los audios.')
        def fill(folder):
            folder = os.path.abspath(os.path.expanduser(folder))
            try:
                entries = list(os.scandir(folder))
            except OSError as exc:
                status.set('No se puede abrir: ' + str(exc))
                return
            path_var.set(folder)
            tree.delete(*tree.get_children())
            folders = sorted((e for e in entries if e.is_dir(follow_symlinks=False)), key=lambda e:e.name.casefold())
            audios = sorted((e for e in entries if e.is_file(follow_symlinks=False) and e.name.lower().endswith(('.mp3','.wav'))), key=lambda e:e.name.casefold())
            if os.path.dirname(folder) != folder:
                tree.insert('', 'end', iid=os.path.dirname(folder), text='📁 .. (subir)', values=('dir',))
            for e in folders:
                tree.insert('', 'end', iid=e.path, text='📁 ' + e.name, values=('dir',))
            for e in audios:
                tree.insert('', 'end', iid=e.path, text='♫ ' + e.name, values=('audio',))
            status.set(f'{len(folders)} carpetas • {len(audios)} archivos MP3/WAV')
        def chosen():
            sel = tree.selection()
            if not sel:
                return None
            path = sel[0]
            if os.path.isdir(path):
                fill(path)
                return None
            return path if os.path.isfile(path) else None
        def browse():
            folder = filedialog.askdirectory(parent=win, initialdir=path_var.get())
            if folder:
                fill(folder)
        def load_deck(deck):
            path = chosen()
            if path:
                self.deck_files[deck] = path
                self.deck_labels[deck].set(os.path.basename(path))
                self.deck_audio[deck] = None
                self.deck_pos[deck] = 0
                status.set('Cargada en tornamesa ' + deck + ': ' + os.path.basename(path))
        def add_playlist():
            path = chosen()
            if path:
                self.tracks.append(path)
                self.listbox.insert('end', os.path.basename(path))
                status.set('Añadida a la lista: ' + os.path.basename(path))
        def assign_cart():
            path = chosen()
            if path:
                self.open_cart_wall()
                self.cart_assign_dialog(path)
        tree.bind('<Double-1>', lambda event: chosen())
        ttk.Button(top, text='Examinar...', command=browse).pack(side='left', padx=5)
        ttk.Button(top, text='Ir', command=lambda: fill(path_var.get())).pack(side='left')
        actions = ttk.Frame(win)
        actions.pack(fill='x', padx=12, pady=7)
        for label, callback in [('A tornamesa A', lambda:load_deck('A')),
                                ('A tornamesa B', lambda:load_deck('B')),
                                ('A lista', add_playlist), ('A Cart Wall', assign_cart)]:
            ttk.Button(actions, text=label, command=callback).pack(side='left', padx=3)
        ttk.Label(win, textvariable=status).pack(anchor='w', padx=12, pady=(0,8))
        fill(path_var.get())

    def cart_assign_dialog(self, path=None):
        path = path or filedialog.askopenfilename(title='Audio del Cart Wall', filetypes=[('Audio','*.mp3 *.wav')])
        if not path:
            return
        dialog = tk.Toplevel(self.root)
        dialog.title('Asignar botón de Cart Wall')
        dialog.geometry('340x230')
        ttk.Label(dialog, text=os.path.basename(path), wraplength=310).pack(padx=10, pady=8)
        bank = tk.StringVar(value='1')
        slot = tk.StringVar(value='1')
        label = tk.StringVar(value=os.path.splitext(os.path.basename(path))[0][:24])
        row = ttk.Frame(dialog)
        row.pack(pady=5)
        ttk.Label(row, text='Banco').pack(side='left')
        ttk.Combobox(row, textvariable=bank, values=('1','2','3'), width=4, state='readonly').pack(side='left', padx=8)
        ttk.Label(row, text='Botón').pack(side='left')
        ttk.Combobox(row, textvariable=slot, values=tuple(str(i) for i in range(1,13)), width=4, state='readonly').pack(side='left', padx=8)
        ttk.Entry(dialog, textvariable=label).pack(fill='x', padx=12, pady=9)
        def save():
            self.cart_banks[bank.get()][int(slot.get())-1] = {'path':path, 'label':label.get().strip() or os.path.basename(path)}
            self.save_cart_wall()
            dialog.destroy()
            self.refresh_cart_windows()
        ttk.Button(dialog, text='Guardar asignación', command=save).pack(pady=5)

    def refresh_cart_windows(self):
        for win, content in list(self.cart_windows.items()):
            if not win.winfo_exists():
                self.cart_windows.pop(win, None)
                continue
            frame, bank_var, status = content
            for child in frame.winfo_children():
                child.destroy()
            for idx, entry in enumerate(self.cart_banks[bank_var.get()]):
                title = entry.get('label', '') if entry else 'Libre'
                if len(title) > 20:
                    title = title[:18] + '…'
                btn = tk.Button(frame, text=f'{idx+1}  {title}', height=3, wraplength=125,
                    bg='#15517b' if entry else '#25364a', fg='white', activebackground='#187ca3',
                    command=lambda i=idx,b=bank_var,s=status: self.cart_play(b.get(),i,s))
                btn.grid(row=idx//4, column=idx%4, padx=4, pady=4, sticky='nsew')
                btn.bind('<Button-3>', lambda event,i=idx,b=bank_var: self.cart_edit(b.get(),i))
            for col in range(4):
                frame.columnconfigure(col, weight=1)

    def cart_play(self, bank, idx, status):
        entry = self.cart_banks[bank][idx]
        if not entry:
            self.cart_edit(bank, idx)
            return
        if not os.path.isfile(entry['path']):
            status.set('Archivo no disponible: ' + entry['path'])
            return
        if self.start_jingle(entry['path']):
            status.set('Reproduciendo: ' + entry.get('label', os.path.basename(entry['path'])))
        else:
            status.set(self.jingle_status.get())

    def cart_edit(self, bank, idx):
        current = self.cart_banks[bank][idx]
        path = filedialog.askopenfilename(title='Asignar audio al botón', filetypes=[('Audio','*.mp3 *.wav')])
        if path:
            self.cart_banks[bank][idx] = {'path':path, 'label':os.path.splitext(os.path.basename(path))[0][:28]}
            self.save_cart_wall()
            self.refresh_cart_windows()

    def open_cart_wall(self):
        for win in list(self.cart_windows):
            if win.winfo_exists():
                win.lift()
                return
        win = tk.Toplevel(self.root)
        win.title('Coca Broadcast Studio • Cart Wall')
        win.geometry('690x490')
        win.minsize(460, 350)
        top = ttk.Frame(win)
        top.pack(fill='x', padx=12, pady=10)
        ttk.Label(top, text='CART WALL • JINGLES Y EFECTOS', font=('Segoe UI', 12, 'bold')).pack(side='left')
        bank = tk.StringVar(value='1')
        ttk.Label(top, text='Banco:').pack(side='left', padx=(20,5))
        combo = ttk.Combobox(top, textvariable=bank, values=('1','2','3'), width=4, state='readonly')
        combo.pack(side='left')
        status = tk.StringVar(value='Clic en un botón libre para asignar audio; clic derecho para cambiarlo.')
        frame = ttk.Frame(win)
        frame.pack(fill='both', expand=True, padx=12, pady=10)
        controls = ttk.Frame(win)
        controls.pack(fill='x', padx=12, pady=8)
        ttk.Button(controls, text='Asignar archivo...', command=self.cart_assign_dialog).pack(side='left')
        ttk.Label(controls, text='3 bancos • 12 botones por banco').pack(side='right')
        ttk.Label(win, textvariable=status, wraplength=640).pack(anchor='w', padx=12, pady=(0,8))
        self.cart_windows[win] = (frame, bank, status)
        combo.bind('<<ComboboxSelected>>', lambda event: self.refresh_cart_windows())
        def on_close():
            self.cart_windows.pop(win, None)
            win.destroy()
        win.protocol('WM_DELETE_WINDOW', on_close)
        self.refresh_cart_windows()

    def open_digital_console(self):
        """Vista flotante que comparte las variables reales con la consola integrada."""
        win = tk.Toplevel(self.root)
        win.title('Coca Broadcast Studio • Consola digital flotante')
        win.geometry('1150x690')
        win.minsize(620, 400)
        self.build_digital_console(win)

    def build_digital_console(self, parent):
        """Interfaz de control compartida; sin un segundo motor ni rutas de audio ficticias."""
        bg, panel, cyan = '#0d192a', '#1a3047', '#36d9ff'
        outer = tk.Frame(parent, bg=bg)
        outer.pack(fill='both', expand=True)
        head = tk.Frame(outer, bg=bg)
        head.pack(fill='x', padx=12, pady=10)
        tk.Label(head, text='CONSOLA DIGITAL PROFESIONAL', bg=bg, fg=cyan,
                 font=('Segoe UI', 15, 'bold')).pack(side='left')
        tk.Button(head, text='Separar ventana', command=self.open_digital_console,
                  bg='#165477', fg='white', relief='flat', padx=12, pady=6).pack(side='right')
        tk.Label(outer, text='Motor local existente • Entradas/medidores disponibles • AUX sin enrutamiento todavía • No transmite a Internet',
                 bg=bg, fg='#b8d3e7', anchor='w').pack(fill='x', padx=12)
        # Un solo desplazamiento vertical para dispositivos, controles y canales.
        viewport = tk.Frame(outer, bg=bg)
        viewport.pack(fill='both', expand=True, padx=8, pady=5)
        scroll = tk.Canvas(viewport, bg=bg, highlightthickness=0)
        vertical = ttk.Scrollbar(viewport, orient='vertical', command=scroll.yview)
        scroll.configure(yscrollcommand=vertical.set)
        vertical.pack(side='right', fill='y')
        scroll.pack(side='left', fill='both', expand=True)
        content = tk.Frame(scroll, bg=bg)
        content_id = scroll.create_window((0, 0), window=content, anchor='nw')
        content.bind('<Configure>', lambda e: scroll.configure(scrollregion=scroll.bbox('all')))
        scroll.bind('<Configure>', lambda e: scroll.itemconfigure(content_id, width=e.width))
        def wheel(e):
            scroll.yview_scroll(-int(e.delta / 120) if e.delta else 0, 'units')
        # Enlazar la rueda cuando el cursor esté sobre el área de la consola.
        def attach_wheel(e):
            scroll.bind_all('<MouseWheel>', wheel)
        def detach_wheel(e):
            scroll.unbind_all('<MouseWheel>')
        viewport.bind('<Enter>', attach_wheel)
        viewport.bind('<Leave>', detach_wheel)
        io = tk.LabelFrame(content, text='DISPOSITIVOS DE AUDIO Y SEÑAL REAL', bg=panel, fg=cyan, padx=10, pady=8)
        io.pack(fill='x', padx=12, pady=5)
        tk.Label(io, text='ENTRADA (micrófono / consola USB)', bg=panel, fg='white').grid(row=0, column=0, sticky='w')
        in_combo = ttk.Combobox(io, textvariable=self.device_name, state='readonly', width=38)
        in_combo['values'] = [f'{i}: {name}' for i, name in self.devices]
        in_combo.grid(row=1, column=0, padx=5, sticky='ew')
        self.modular_mic_combos.append(in_combo)
        tk.Label(io, text='SALIDA (bocinas / audífonos / interfaz)', bg=panel, fg='white').grid(row=0, column=1, sticky='w')
        out_combo = ttk.Combobox(io, textvariable=self.output_name, state='readonly', width=38)
        out_combo['values'] = ['Predeterminada de Windows'] + [f'{i}: {name}' for i, name in self.output_devices]
        out_combo.grid(row=1, column=1, padx=5, sticky='ew')
        def rescan():
            self.detect()
            out_combo['values'] = ['Predeterminada de Windows'] + [f'{i}: {name}' for i, name in self.output_devices]
        tk.Button(io, text='Actualizar', command=rescan, bg='#17658a', fg='white').grid(row=1, column=2, padx=5)
        tk.Button(io, text='Iniciar audio', command=self.start_audio, bg='#148447', fg='white').grid(row=2, column=0, pady=5, sticky='w')
        tk.Button(io, text='Detener audio', command=self.stop_audio, bg='#923547', fg='white').grid(row=2, column=1, pady=5, sticky='w')
        for r, label, var in [(3, 'ENTRADA • nivel detectado', self.input_peak),
                              (4, 'MASTER L • señal procesada', self.output_left),
                              (5, 'MASTER R • señal procesada', self.output_right)]:
            tk.Label(io, text=label, bg=panel, fg='white').grid(row=r, column=0, sticky='w')
            ttk.Progressbar(io, maximum=100, variable=var, length=240).grid(row=r, column=1, sticky='ew', pady=2)
        tk.Label(io, text='Cambia de dispositivo con el audio detenido. MASTER es mezcla local, no emisión por Internet.',
                 bg=panel, fg='#b8d3e7', wraplength=850).grid(row=6, column=0, columnspan=3, sticky='w')
        io.columnconfigure(0, weight=1)
        io.columnconfigure(1, weight=1)
        toolbar = tk.Frame(content, bg=bg)
        toolbar.pack(fill='x', padx=12, pady=(3, 0))
        tk.Button(toolbar, text='+ AÑADIR CANAL AUX', bg='#148447', fg='white',
                  command=self.console_add_aux).pack(side='left', padx=(0, 8))
        tk.Button(toolbar, text='QUITAR ÚLTIMO AUX', bg='#923547', fg='white',
                  command=self.console_remove_aux).pack(side='left')
        tk.Label(toolbar, text='AUX: configuración visual; la captura y el envío a MASTER requieren una etapa posterior.',
                 bg=bg, fg='#b8d3e7').pack(side='left', padx=12)
        meter_options = tk.Frame(content, bg=bg)
        meter_options.pack(fill='x', padx=12, pady=(8, 2))
        tk.Label(meter_options, text='MEDIDORES DE CANAL:', bg=bg, fg='white').pack(side='left', padx=(0, 8))
        meter_style = tk.StringVar(master=self.root, value='Vertical LED')
        ttk.Combobox(meter_options, textvariable=meter_style, state='readonly', width=22,
                     values=['Vertical LED', 'Horizontal azul']).pack(side='left')
        tk.Label(meter_options, text='MIC / Deck / Fondo / Música / MASTER: señal real · AUX sin ruta: apagado',
                 bg=bg, fg='#b8d3e7').pack(side='left', padx=12)
        area = tk.Frame(content, bg=bg)
        area.pack(fill='both', expand=True, padx=8, pady=8)
        canvas = tk.Canvas(area, bg=bg, highlightthickness=0)
        xbar = ttk.Scrollbar(area, orient='horizontal', command=canvas.xview)
        canvas.configure(xscrollcommand=xbar.set)
        xbar.pack(side='bottom', fill='x')
        canvas.pack(side='left', fill='both', expand=True)
        inside = tk.Frame(canvas, bg=bg)
        window_id = canvas.create_window((0, 0), window=inside, anchor='nw')
        inside.bind('<Configure>', lambda e: canvas.configure(scrollregion=canvas.bbox('all')))
        canvas.bind('<Configure>', lambda e: canvas.itemconfigure(window_id, height=650))
        canvas.configure(height=660)
        self.aux_console_views.append((inside, panel, cyan, meter_style))
        channels = [
            ('MIC 1', self.mic_vol, 'Micrófono principal'),
            ('DECK A', self.deck_volume['A'], 'Tornamesa A'),
            ('DECK B', self.deck_volume['B'], 'Tornamesa B'),
            ('FONDO', self.bg_volume, 'Fondo musical'),
            ('MÚSICA', self.music_vol, 'Volumen musical general'),
        ]
        for title, var, detail in channels:
            col = tk.Frame(inside, bg=panel, width=160, bd=1, relief='ridge')
            col.pack(side='left', fill='y', padx=5, pady=5)
            col.pack_propagate(False)
            tk.Label(col, text=title, bg=panel, fg=cyan, font=('Segoe UI', 11, 'bold')).pack(pady=(16, 3))
            tk.Label(col, text=detail, bg=panel, fg='white', wraplength=145,
                     font=('Segoe UI', 8)).pack(pady=(0, 12))
            enabled = tk.BooleanVar(value=True)
            button = tk.Button(col, text='DISPONIBLE', bg='#148447', fg='white', relief='raised', width=12)
            button.pack(pady=4)
            # Indicador deshabilitado: no simula encendido de un canal que no está enrutado.
            button.configure(state='disabled')
            if title == 'MIC 1':
                tk.Button(col, text='MIC F9 • SILENCIO', bg='#923547', fg='white', relief='flat',
                          command=self.toggle_mute).pack(pady=4)
            else:
                tk.Label(col, text='Mute/PFL: pendiente', bg=panel, fg='#b4c5d5').pack(pady=5)
            if title in ('DECK A', 'DECK B'):
                deck_id = 'A' if title == 'DECK A' else 'B'
                actions = tk.Frame(col, bg=panel)
                actions.pack(pady=5)
                for symbol, action, color in [
                    ('▶', self.deck_play, '#148447'),
                    ('Ⅱ', self.deck_pause, '#8c7023'),
                    ('■', self.deck_stop, '#923547')]:
                    tk.Button(actions, text=symbol, command=lambda a=action, d=deck_id: a(d),
                              bg=color, fg='white', width=3).pack(side='left', padx=2)
                tk.Label(col, textvariable=self.deck_labels[deck_id], bg=panel,
                         fg='#b8d3e7', wraplength=145).pack(pady=2)
            elif title == 'FONDO':
                actions = tk.Frame(col, bg=panel)
                actions.pack(pady=5)
                for symbol, action, color in [
                    ('▶', self.bg_play, '#148447'),
                    ('Ⅱ', self.bg_pause, '#8c7023'),
                    ('■', self.bg_stop, '#923547')]:
                    tk.Button(actions, text=symbol, command=action, bg=color,
                              fg='white', width=3).pack(side='left', padx=2)
            dial = tk.Canvas(col, width=90, height=95, bg=panel, highlightthickness=0)
            dial.pack(pady=(16, 5))
            def draw(*_, c=dial, v=var):
                try:
                    value = max(0, min(100, float(v.get())))
                    c.delete('all')
                    c.create_oval(15, 7, 75, 67, outline='#49657b', width=5)
                    angle = math.radians(225 - value*2.7)
                    c.create_line(45,37,45+21*math.cos(angle),37-21*math.sin(angle),
                                  fill=cyan, width=4)
                    c.create_text(45,83,text=f'{value:.0f}%',fill='white',font=('Segoe UI',11,'bold'))
                except tk.TclError:
                    pass
            var.trace_add('write', draw)
            draw()
            # Un mismo componente visual mantiene fader y señal L/R alineados.
            self.console_fader_with_meter(col, var, self.channel_levels[title],
                                          meter_style, panel, cyan)

        master = tk.Frame(inside, bg='#122b41', width=180, bd=2, relief='ridge')
        master.pack(side='left', fill='y', padx=5, pady=5)
        master.pack_propagate(False)
        tk.Label(master, text='MASTER / MONITOR', bg='#122b41', fg=cyan,
                 font=('Segoe UI', 11, 'bold')).pack(pady=16)
        tk.Label(master, text='Salida local existente', bg='#122b41', fg='white').pack(pady=4)
        tk.Label(master, text='No hay control MASTER de salida independiente todavía.',
                 bg='#122b41', fg='#b8d3e7', wraplength=155).pack(padx=8, pady=12)
        tk.Button(master, text='MIC ON / OFF (F9)', command=self.toggle_mute,
                  bg='#17658a', fg='white', relief='flat').pack(pady=8)
        tk.Label(master, textvariable=self.status, bg='#122b41', fg='#e8f3fc',
                 wraplength=150).pack(pady=15, padx=8)
        # MASTER no dispone todavía de un fader de ganancia independiente.
        # El control visual permanece bloqueado para evitar representar una ruta inexistente.
        self.console_fader_with_meter(master, None, (self.output_left, self.output_right),
                                      meter_style, '#122b41', cyan, 'MASTER L/R')
        tk.Label(master, text='AUX configurables desde la barra superior', bg='#122b41',
                 fg='#b8d3e7', wraplength=155).pack(pady=8)
        self.console_render_aux(inside, panel, cyan, meter_style)

    def console_fader_with_meter(self, parent, variable, signals, style, bg, cyan,
                                 label='SEÑAL L/R'):
        """Componente reutilizable: fader izquierdo y medición real L/R a la derecha."""
        strip = tk.Frame(parent, bg=bg)
        strip.pack(pady=(6, 4), padx=3)
        left = tk.Frame(strip, bg=bg)
        left.pack(side='left', padx=(0, 1))
        if variable is not None:
            tk.Scale(left, from_=100, to=0, variable=variable, orient='vertical',
                     length=190, showvalue=False, sliderlength=27, width=16,
                     troughcolor='#112238', bg=bg, fg='white',
                     activebackground=cyan, highlightthickness=0).pack()
        else:
            # Fader no operativo hasta implementar el control MASTER independiente.
            tk.Scale(left, from_=100, to=0, orient='vertical', length=190,
                     showvalue=False, sliderlength=27, width=16,
                     troughcolor='#112238', bg=bg, highlightthickness=0,
                     state='disabled').pack()
        tk.Label(left, text='FADER', bg=bg, fg='#c6dbe9',
                 font=('Segoe UI', 8, 'bold')).pack()
        right = tk.Frame(strip, bg=bg)
        right.pack(side='left', padx=(1, 0))
        self.console_stereo_meter(right, signals, style, bg, cyan, label,
                                  compact=True)

    def console_stereo_meter(self, parent, signals, style, bg, cyan, label='SEÑAL L/R', compact=False):
        """Medidor estéreo LED o azul conectado a RMS real de cada fuente."""
        frame = tk.Frame(parent, bg=bg)
        frame.pack(fill='x', padx=1 if compact else 5, pady=(4, 1) if compact else (4, 10))
        tk.Label(frame, text=label, bg=bg, fg='#c6dbe9', font=('Segoe UI', 8, 'bold')).pack()
        canvas = tk.Canvas(frame, width=55 if compact else 130, height=190 if compact else 125, bg=bg, highlightthickness=0)
        canvas.pack()
        def paint(*_):
            try:
                canvas.delete('all')
                values = [max(0., min(100., float(v.get()))) for v in signals]
                if style.get() == 'Vertical LED':
                    for side, value in enumerate(values):
                        x = (6 + side * 23) if compact else (42 + side * 27)
                        for j in range(15):
                            y = (167 - j * 10) if compact else (106 - j * 7)
                            active = value >= (j + 1) * 100 / 15
                            color = ('#f45e65' if j >= 13 else '#e9c951' if j >= 11 else '#34d6a3') if active else '#2d4960'
                            canvas.create_rectangle(x, y-(8 if compact else 5), x+(17 if compact else 19), y, fill=color, outline='')
                    canvas.create_text(27 if compact else 67, 182 if compact else 118, text='L    R' if compact else 'L      R', fill='#d5e6f2', font=('Segoe UI', 8))
                else:
                    for side, value in enumerate(values):
                        y = (63 + side * 35) if compact else (42 + side * 28)
                        canvas.create_text(7 if compact else 9, y+8, text='L' if side == 0 else 'R', fill='white', font=('Segoe UI', 8))
                        canvas.create_rectangle(17 if compact else 20, y, 53 if compact else 125, y+16, fill='#29465e', outline='#54748a')
                        if value:
                            canvas.create_rectangle(18 if compact else 21, y+1, (18 + value * .34) if compact else (21 + value * 1.03), y+15, fill=cyan, outline='')
            except tk.TclError:
                pass
        for variable in signals:
            variable.trace_add('write', paint)
        style.trace_add('write', paint)
        paint()

    def console_signal_meter(self, parent, signal, style, bg, cyan, label='NIVEL'):
        """Medidor de señal vinculado a las variables del motor, nunca simulado."""
        frame = tk.Frame(parent, bg=bg)
        frame.pack(fill='x', padx=8, pady=5)
        tk.Label(frame, text=label if signal is not None else 'SEÑAL SIN MEDICIÓN',
                 bg=bg, fg='#c6dbe9', font=('Segoe UI', 8)).pack()
        if signal is None:
            tk.Label(frame, text='Pendiente', bg=bg, fg='#ffca82').pack()
            return
        bar = tk.Canvas(frame, width=120, height=110, bg=bg, highlightthickness=0)
        bar.pack()
        def paint(*_):
            try:
                bar.delete('all')
                value = max(0.0, min(100.0, float(signal.get())))
                if style.get() == 'Vertical LED':
                    for j in range(15):
                        y = 104 - j * 7
                        on = value >= (j + 1) * 100 / 15
                        color = ('#f45e65' if j >= 13 else '#e9c951' if j >= 11 else '#34d6a3') if on else '#2d4960'
                        bar.create_rectangle(43, y-5, 78, y, fill=color, outline='')
                else:
                    bar.create_rectangle(4, 42, 116, 64, fill='#29465e', outline='#54748a')
                    if value:
                        bar.create_rectangle(5, 43, 5 + value * 1.1, 63, fill=cyan, outline='')
                bar.create_text(60, 107 if style.get() == 'Horizontal azul' else 5,
                                text=f'{value:.0f}%', fill='white', font=('Segoe UI', 8))
            except tk.TclError:
                pass
        signal.trace_add('write', paint)
        style.trace_add('write', paint)
        paint()

    def console_add_aux(self):
        if len(self.aux_console_channels) >= 16:
            from tkinter import messagebox
            messagebox.showinfo('Canales AUX', 'Máximo de 16 canales AUX en esta etapa.')
            return
        number = len(self.aux_console_channels) + 1
        self.aux_console_channels.append({
            'name': tk.StringVar(master=self.root, value=f'AUX {number}'),
            'source': tk.StringVar(master=self.root, value='Sin asignar'),
            'dest': tk.StringVar(master=self.root, value='Sin ruta'),
            'gain': tk.DoubleVar(master=self.root, value=70),
        })
        self.console_refresh_aux()

    def console_remove_aux(self):
        if self.aux_console_channels:
            self.aux_console_channels.pop()
            self.console_refresh_aux()

    def console_refresh_aux(self):
        alive = []
        for inside, panel, cyan, meter_style in self.aux_console_views:
            try:
                if inside.winfo_exists():
                    self.console_render_aux(inside, panel, cyan, meter_style)
                    alive.append((inside, panel, cyan, meter_style))
            except tk.TclError:
                pass
        self.aux_console_views = alive

    def console_render_aux(self, inside, panel, cyan, meter_style):
        if hasattr(inside, '_aux_frames'):
            for widget in inside._aux_frames:
                try:
                    widget.destroy()
                except tk.TclError:
                    pass
        inside._aux_frames = []
        for number, config in enumerate(self.aux_console_channels, 1):
            col = tk.Frame(inside, bg=panel, width=195, bd=1, relief='ridge')
            col.pack(side='left', fill='y', padx=5, pady=5)
            col.pack_propagate(False)
            inside._aux_frames.append(col)
            tk.Label(col, text=f'CANAL AUX {number}', bg=panel, fg=cyan,
                     font=('Segoe UI', 10, 'bold')).pack(pady=(12, 4))
            tk.Entry(col, textvariable=config['name'], width=20).pack(padx=7, pady=4)
            tk.Label(col, text='Fuente prevista', bg=panel, fg='white').pack()
            ttk.Combobox(col, textvariable=config['source'], state='readonly', width=20,
                         values=['Sin asignar', 'Micrófono / USB', 'Entrada de línea',
                                 'Interfaz externa', 'Reproductor externo']).pack(padx=6, pady=4)
            tk.Label(col, text='Destino previsto', bg=panel, fg='white').pack()
            ttk.Combobox(col, textvariable=config['dest'], state='readonly', width=20,
                         values=['Sin ruta', 'MASTER (pendiente)',
                                 'MONITOR (pendiente)']).pack(padx=6, pady=4)
            tk.Label(col, text='Ganancia propuesta', bg=panel, fg='white').pack(pady=(9, 0))
            # Sin señal: no fingir un nivel para un canal AUX todavía no enrutado.
            aux_zero = (tk.DoubleVar(master=col, value=0), tk.DoubleVar(master=col, value=0))
            self.console_fader_with_meter(col, config['gain'], aux_zero,
                                          meter_style, panel, cyan)
            tk.Label(col, text='SIN AUDIO / SIN RUTA', bg=panel, fg='#ffca82', wraplength=175).pack(pady=4)
            tk.Label(col, text='Este canal aún no captura ni mezcla audio.', bg=panel,
                     fg='#b8d3e7', wraplength=170).pack(padx=8)

    def open_floating_controls(self):
        """Control remoto flotante; no reparenta widgets ni reinicia audio."""
        win = tk.Toplevel(self.root)
        win.title('Coca Broadcast Studio • Panel flotante')
        win.geometry('460x470')
        win.configure(bg=BG)
        ttk.Label(win, text='PANEL FLOTANTE DE CABINA', font=('Segoe UI', 13, 'bold')).pack(pady=12)
        ttk.Label(win, text='Puedes mover y redimensionar esta ventana.\nCerrar no detiene el audio.',
                  justify='center').pack(pady=(0, 12))
        for deck in ('A', 'B'):
            frame = ttk.LabelFrame(win, text='Tornamesa ' + deck)
            frame.pack(fill='x', padx=12, pady=7)
            ttk.Label(frame, textvariable=self.deck_labels[deck], wraplength=420).pack(anchor='w', padx=8, pady=4)
            row = ttk.Frame(frame)
            row.pack(fill='x', padx=8, pady=5)
            ttk.Button(row, text='Cargar', command=lambda d=deck: self.deck_load(d)).pack(side='left')
            ttk.Button(row, text='▶', command=lambda d=deck: self.deck_play(d)).pack(side='left')
            ttk.Button(row, text='Ⅱ', command=lambda d=deck: self.deck_pause(d)).pack(side='left')
            ttk.Button(row, text='■', command=lambda d=deck: self.deck_stop(d)).pack(side='left')
            ttk.Label(row, textvariable=self.deck_time[deck]).pack(side='right')
        frame = ttk.LabelFrame(win, text='Fondo musical')
        frame.pack(fill='x', padx=12, pady=7)
        ttk.Label(frame, textvariable=self.bg_label, wraplength=420).pack(anchor='w', padx=8)
        row = ttk.Frame(frame)
        row.pack(fill='x', padx=8, pady=6)
        for label, action in [('Cargar', self.bg_load), ('▶', self.bg_play),
                              ('Ⅱ', self.bg_pause), ('■', self.bg_stop)]:
            ttk.Button(row, text=label, command=action).pack(side='left')
        ttk.Button(win, text='🎤  Micrófono F9', command=self.toggle_mute).pack(pady=10)
        ttk.Label(win, textvariable=self.pro_mic_status).pack()

    def console_section_title(self, parent, text):
        tk.Label(parent, text=text, bg='#102847', fg='#48c9ff',
                 font=('Segoe UI', 12, 'bold'), padx=16, pady=12).pack(fill='x', padx=12, pady=9)

    def scrollable_panel(self, parent, name):
        """Área vertical y horizontal desplazable, con rueda activa al situarse encima."""
        holder = ttk.Frame(parent)
        holder.pack(fill='both', expand=True)
        ybar = ttk.Scrollbar(holder, orient='vertical')
        xbar = ttk.Scrollbar(holder, orient='horizontal')
        canvas = tk.Canvas(holder, bg=BG, highlightthickness=0,
                           yscrollcommand=ybar.set, xscrollcommand=xbar.set)
        ybar.configure(command=canvas.yview)
        xbar.configure(command=canvas.xview)
        ybar.pack(side='right', fill='y')
        xbar.pack(side='bottom', fill='x')
        canvas.pack(side='left', fill='both', expand=True)
        content = ttk.Frame(canvas)
        window_id = canvas.create_window((0, 0), window=content, anchor='nw')
        content.bind('<Configure>', lambda e: canvas.configure(scrollregion=canvas.bbox('all')))
        canvas.bind('<Configure>', lambda e: canvas.itemconfigure(window_id, width=max(e.width, 790)))
        def wheel(e):
            if e.delta:
                canvas.yview_scroll(-int(e.delta / 120), 'units')
        # Activar la rueda sobre controles hijos sin capturar la rueda de otros paneles.
        def enter(_):
            canvas.bind_all('<MouseWheel>', wheel)
        def leave(_):
            canvas.unbind_all('<MouseWheel>')
        holder.bind('<Enter>', enter)
        holder.bind('<Leave>', leave)
        setattr(self, name + '_scroll_canvas', canvas)
        return content

    def setup_unified(self, parent):
        """Panel integrado: controles vinculados al mismo motor de audio existente."""
        header = ttk.Frame(parent)
        header.pack(fill='x', padx=8, pady=6)
        ttk.Label(header, text='CABINA PROFESIONAL UNIFICADA', font=('Segoe UI', 12, 'bold')).pack(side='left')
        ttk.Label(header, textvariable=self.active_profile).pack(side='left', padx=15)
        ttk.Button(header, text='Perfiles', command=self.profiles_dialog).pack(side='right', padx=3)
        ttk.Button(header, text='Vista visual completa', command=lambda: self.main_tabs.select(7)).pack(side='right', padx=3)
        viewport = ttk.Frame(parent)
        viewport.pack(fill='both', expand=True, padx=5, pady=3)
        scroll_y = ttk.Scrollbar(viewport, orient='vertical')
        scroll_x = ttk.Scrollbar(viewport, orient='horizontal')
        canvas = tk.Canvas(viewport, bg=BG, highlightthickness=0, yscrollcommand=scroll_y.set, xscrollcommand=scroll_x.set)
        scroll_y.configure(command=canvas.yview)
        scroll_x.configure(command=canvas.xview)
        scroll_y.pack(side='right', fill='y')
        scroll_x.pack(side='bottom', fill='x')
        canvas.pack(side='left', fill='both', expand=True)
        content = ttk.Frame(canvas)
        win_id = canvas.create_window((0,0), window=content, anchor='nw')
        content.bind('<Configure>', lambda e: canvas.configure(scrollregion=canvas.bbox('all')))
        canvas.bind('<Configure>', lambda e: canvas.itemconfigure(win_id, width=max(e.width, 1000)))
        canvas.bind('<MouseWheel>', lambda e: canvas.yview_scroll(-int(e.delta/120), 'units'))
        def pro_wheel(e):
            canvas.yview_scroll(-int(e.delta / 120), 'units')
        viewport.bind('<Enter>', lambda e: canvas.bind_all('<MouseWheel>', pro_wheel))
        viewport.bind('<Leave>', lambda e: canvas.unbind_all('<MouseWheel>'))
        self.unified_scroll_canvas = canvas
        controls = ttk.Frame(content)
        controls.pack(fill='x', padx=8, pady=4)
        for name, value in [('RADIO: una canción', 'radio'), ('DJ: mezcla simultánea', 'dj')]:
            ttk.Radiobutton(controls, text=name, variable=self.deck_mode, value=value,
                            command=self.change_deck_mode).pack(side='left', padx=5)
        ttk.Checkbutton(controls, text='Luces', variable=self.visual_enabled).pack(side='left', padx=8)
        ttk.Combobox(controls, textvariable=self.visual_intensity, state='readonly',
                     values=['Suave', 'Normal', 'Espectacular'], width=14).pack(side='left')
        layout = ttk.Frame(content)
        layout.pack(fill='both', expand=True, padx=8, pady=4)
        for col, kind in enumerate(('A', 'mic', 'B')):
            layout.columnconfigure(col, weight=3 if kind == 'mic' else 4)
            pane = ttk.LabelFrame(layout, text={'A':'TORNAMESA A', 'mic':'MEZCLADOR / MICRÓFONO', 'B':'TORNAMESA B'}[kind])
            pane.grid(row=0, column=col, sticky='nsew', padx=3)
            self.build_module(pane, kind)
            ttk.Button(pane, text='Separar ventana', command=lambda k=kind: self.open_module(k)).pack(anchor='e', padx=8, pady=5)
        layout.rowconfigure(0, weight=1)
        ttk.Label(content, text='Desplázate hacia abajo para ver el crossfader y el fondo musical.').pack(anchor='w', padx=12, pady=3)
        foot = ttk.LabelFrame(content, text='CROSSFADER / FONDO MUSICAL')
        foot.pack(fill='x', padx=10, pady=5)
        line = ttk.Frame(foot)
        line.pack(fill='x', padx=8, pady=5)
        ttk.Label(line, text='A').pack(side='left')
        ttk.Scale(line, from_=0, to=100, variable=self.crossfade).pack(side='left', fill='x', expand=True, padx=5)
        ttk.Label(line, text='B').pack(side='left')
        ttk.Button(line, text='Fondo musical', command=lambda: self.open_module('bg')).pack(side='left', padx=8)
        ttk.Label(content, text='Los paneles comparten el motor de audio. Las ondas también se muestran aquí.').pack(pady=4)

    def load_profiles(self):
        self.profiles = {}
        try:
            with open(self.profile_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
            if isinstance(data, dict):
                self.profiles = {str(k):v for k,v in data.items() if isinstance(v, dict)}
        except (OSError, ValueError, TypeError):
            pass

    def save_profiles(self):
        os.makedirs(os.path.dirname(self.profile_path), exist_ok=True)
        tmp = self.profile_path + '.tmp'
        with open(tmp, 'w', encoding='utf-8') as f:
            json.dump(self.profiles, f, ensure_ascii=False, indent=2)
        os.replace(tmp, self.profile_path)

    def profiles_dialog(self):
        win = tk.Toplevel(self.root)
        win.title('Locutores • perfiles locales (sin autenticación)')
        win.geometry('510x490')
        win.configure(bg=BG)
        ttk.Label(win, text='PERFILES DE LOCUTORES', font=('Segoe UI', 13, 'bold')).pack(pady=10)
        ttk.Label(win, text='Estos perfiles guardan preferencias locales; no son cuentas con contraseña.').pack(pady=4)
        selected = tk.StringVar(value=self.active_profile.get() if self.active_profile.get() in self.profiles else '')
        picker = ttk.Combobox(win, textvariable=selected, state='readonly', values=sorted(self.profiles))
        picker.pack(fill='x', padx=20, pady=5)
        fields = {}
        for label, key in [('Nombre del locutor', 'name'), ('Programa', 'program'), ('Horario', 'schedule'), ('Fotografía (ruta local)', 'photo')]:
            ttk.Label(win, text=label).pack(anchor='w', padx=20, pady=(6, 1))
            entry = ttk.Entry(win)
            entry.pack(fill='x', padx=20)
            fields[key] = entry
        def show_profile(event=None):
            data = self.profiles.get(selected.get(), {})
            for key, entry in fields.items():
                entry.delete(0, 'end')
                entry.insert(0, data.get(key, ''))
        picker.bind('<<ComboboxSelected>>', show_profile)
        show_profile()
        def save():
            name = fields['name'].get().strip()[:80]
            if not name:
                messagebox.showwarning('Locutor', 'Escribe el nombre del locutor.', parent=win)
                return
            old = selected.get()
            data = {k: e.get().strip()[:300] for k,e in fields.items()}
            data.update({'deck_orientation': self.deck_orientation.get(),
                         'visual_A': self.visual_style['A'].get(), 'visual_B': self.visual_style['B'].get(),
                         'mic_volume': self.mic_vol.get(), 'duck_pct': self.duck_pct.get(),
                         'theme': self.theme_name.get()})
            if old and old != name and old in self.profiles:
                del self.profiles[old]
            self.profiles[name] = data
            self.save_profiles()
            selected.set(name)
            picker.configure(values=sorted(self.profiles))
            self.active_profile.set(name)
            messagebox.showinfo('Perfil', 'Perfil guardado en este equipo.', parent=win)
        def load():
            name = selected.get()
            if name not in self.profiles:
                return
            data = self.profiles[name]
            self.active_profile.set(name)
            self.apply_theme(data.get('theme', self.theme_name.get()))
            self.deck_orientation.set(data.get('deck_orientation', 'horizontal'))
            for deck in ('A', 'B'):
                style = data.get('visual_' + deck)
                if style in ('Barras dinámicas', 'Onda real', 'Espectro', 'Ondas circulares', 'Ecualizador arcoíris', 'Luces láser', 'Anillos neón', 'Partículas musicales'):
                    self.visual_style[deck].set(style)
            for key, var in [('mic_volume', self.mic_vol), ('duck_pct', self.duck_pct)]:
                try:
                    var.set(max(0, min(100, float(data[key]))))
                except (ValueError, TypeError, KeyError):
                    pass
            self.deck_relayout()
            win.destroy()
        buttons = ttk.Frame(win)
        buttons.pack(pady=14)
        ttk.Button(buttons, text='Guardar perfil', command=save).pack(side='left', padx=5)
        ttk.Button(buttons, text='Cargar perfil', command=load).pack(side='left', padx=5)
        ttk.Button(buttons, text='Nuevo', command=lambda: (selected.set(''), [e.delete(0, 'end') for e in fields.values()])).pack(side='left', padx=5)

    def open_modular_cabin(self):
        """Cabina modular: vistas remotas; nunca mueve los widgets del motor original."""
        win = tk.Toplevel(self.root)
        win.title('Coca Broadcast Studio 1.0.2 • Cabina auxiliar')
        win.geometry('1120x660')
        win.minsize(750, 480)
        win.configure(bg=BG)
        top = ttk.Frame(win)
        top.pack(fill='x', padx=10, pady=8)
        ttk.Label(top, text='CABINA MODULAR • A / MEZCLADOR / B', font=('Segoe UI', 13, 'bold')).pack(side='left')
        ttk.Button(top, text='Abrir cabina clásica', command=lambda: self.main_tabs.select(6)).pack(side='right', padx=5)
        ttk.Button(top, text='Flotar A', command=lambda: self.open_module('A')).pack(side='right', padx=4)
        ttk.Button(top, text='Flotar mezclador', command=lambda: self.open_module('mic')).pack(side='right', padx=4)
        ttk.Button(top, text='Flotar B', command=lambda: self.open_module('B')).pack(side='right', padx=4)
        body = ttk.Frame(win)
        body.pack(fill='both', expand=True, padx=8)
        body.columnconfigure(0, weight=4)
        body.columnconfigure(1, weight=3)
        body.columnconfigure(2, weight=4)
        body.rowconfigure(0, weight=1)
        for col, kind in enumerate(('A', 'mic', 'B')):
            panel = ttk.LabelFrame(body, text={'A':'TORNAMESA A','mic':'MEZCLADOR / MICRÓFONO','B':'TORNAMESA B'}[kind])
            panel.grid(row=0, column=col, sticky='nsew', padx=4, pady=5)
            self.build_module(panel, kind)
        bottom = ttk.LabelFrame(win, text='MODO RADIO / DJ • CROSSFADER')
        bottom.pack(fill='x', padx=12, pady=5)
        modes = ttk.Frame(bottom)
        modes.pack(fill='x', padx=6, pady=4)
        for title, mode in [('Radio: una canción', 'radio'), ('DJ: mezcla simultánea', 'dj')]:
            ttk.Radiobutton(modes, text=title, variable=self.deck_mode, value=mode,
                            command=self.change_deck_mode).pack(side='left', padx=6)
        ttk.Label(bottom, text='A').pack(side='left', padx=8)
        ttk.Scale(bottom, from_=0, to=100, variable=self.crossfade).pack(side='left', fill='x', expand=True)
        ttk.Label(bottom, text='B').pack(side='left', padx=8)
        ttk.Label(win, text='Cerrar u ocultar esta ventana no detiene el audio. La cabina clásica permanece disponible.').pack(pady=(2, 7))

    def open_module(self, kind):
        title = {'A':'Tornamesa A', 'B':'Tornamesa B', 'mic':'Mezclador / micrófono', 'bg':'Fondo musical'}[kind]
        win = tk.Toplevel(self.root)
        win.title('Coca Broadcast Studio • ' + title)
        win.geometry('390x440' if kind in ('A', 'B') else '380x490')
        win.configure(bg=BG)
        self.build_module(win, kind)

    def console_fader(self, parent, variable, title):
        """Fader de consola enlazado a la variable de audio existente."""
        frame = ttk.LabelFrame(parent, text=title)
        frame.pack(fill='x', padx=8, pady=5)
        row = ttk.Frame(frame)
        row.pack(anchor='center', pady=5)
        canvas = tk.Canvas(row, width=80, height=95, bg='#0c2340', highlightthickness=0)
        canvas.pack(side='left', padx=10)
        fader = tk.Scale(row, from_=100, to=0, orient='vertical', variable=variable,
                         length=130, resolution=1, showvalue=False, width=18,
                         sliderlength=28, troughcolor='#142c46', bg='#203b61',
                         fg='white', highlightthickness=0)
        fader.pack(side='left', padx=10)
        label = ttk.Label(frame)
        label.pack(pady=(0, 5))
        def draw(*_):
            try:
                value = max(0, min(100, float(variable.get())))
                canvas.delete('all')
                canvas.create_oval(9, 8, 71, 70, fill='#263648', outline='#60b9db', width=3)
                angle = math.radians(225 - value * 2.7)
                canvas.create_line(40, 39, 40 + 24 * math.cos(angle),
                                   39 - 24 * math.sin(angle), fill='#27c8f4', width=5)
                canvas.create_text(40, 82, text=f'{value:.0f}%', fill='white', font=('Segoe UI', 10, 'bold'))
                label.configure(text=f'Nivel del canal: {value:.0f}%')
            except (tk.TclError, ValueError):
                pass
        variable.trace_add('write', draw)
        draw()
        return frame

    def build_module(self, parent, kind):
        """Controles compartidos con la cabina original, sin crear un segundo motor de audio."""
        if kind in ('A', 'B'):
            d = kind
            ttk.Label(parent, textvariable=self.deck_labels[d], wraplength=300,
                      font=('Segoe UI', 10, 'bold')).pack(anchor='w', padx=9, pady=8)
            ttk.Label(parent, textvariable=self.deck_artist[d], wraplength=300).pack(anchor='w', padx=9)
            ttk.Label(parent, textvariable=self.deck_album[d], wraplength=300).pack(anchor='w', padx=9)
            ttk.Label(parent, textvariable=self.deck_time[d]).pack(anchor='e', padx=9, pady=6)
            row = ttk.Frame(parent)
            row.pack(fill='x', padx=5, pady=6)
            for label, fn in [('Cargar', self.deck_load), ('▶', self.deck_play),
                              ('Ⅱ', self.deck_pause), ('■', self.deck_stop)]:
                ttk.Button(row, text=label, command=lambda f=fn, deck=d: f(deck)).pack(side='left', padx=1)
            ttk.Label(parent, text='Volumen').pack(anchor='w', padx=9)
            self.console_fader(parent, self.deck_volume[d], 'FADER / PERILLA DIGITAL')
            ttk.Label(parent, text='Visualizador animado').pack(anchor='w', padx=9, pady=(10, 2))
            wave = tk.Canvas(parent, height=58, bg='#0c2340', highlightthickness=0)
            wave.pack(fill='x', padx=9, pady=3)
            self.unified_deck_wave[d] = wave
            progress = ttk.Progressbar(parent, orient='horizontal', mode='determinate', maximum=100)
            progress.pack(fill='x', padx=9, pady=3)
            self.unified_deck_progress[d] = progress
            ttk.Combobox(parent, textvariable=self.visual_style[d], state='readonly',
                         values=['Barras dinámicas', 'Onda real', 'Espectro', 'Ondas circulares',
                                 'Ecualizador arcoíris', 'Luces láser', 'Anillos neón', 'Partículas musicales']).pack(fill='x', padx=9)
            ttk.Label(parent, textvariable=self.deck_state_label[d]).pack(anchor='w', padx=9, pady=10)
        elif kind == 'mic':
            ttk.Label(parent, text='Dispositivo de entrada').pack(anchor='w', padx=8, pady=(10, 2))
            combo = ttk.Combobox(parent, textvariable=self.device_name, state='readonly', width=25)
            combo['values'] = [f'{i}: {name}' for i, name in self.devices]
            combo.pack(fill='x', padx=8)
            # Ambas vistas comparten device_name; no es necesario acceder a self.combo
            # durante la construcción de la cabina profesional.
            self.modular_mic_combos.append(combo)
            ttk.Button(parent, text='Actualizar dispositivos', command=self.detect).pack(fill='x', padx=8, pady=5)
            ttk.Button(parent, text='Iniciar audio', command=self.start_audio).pack(fill='x', padx=8, pady=3)
            ttk.Button(parent, text='Detener audio', command=self.stop_audio).pack(fill='x', padx=8, pady=3)
            ttk.Button(parent, text='Micrófono ON/OFF (F9)', command=self.toggle_mute).pack(fill='x', padx=8, pady=5)
            ttk.Label(parent, textvariable=self.pro_mic_status, wraplength=240).pack(anchor='w', padx=8, pady=5)
            ttk.Label(parent, text='Volumen del micrófono').pack(anchor='w', padx=8)
            self.console_fader(parent, self.mic_vol, 'FADER / PERILLA DIGITAL')
            ttk.Checkbutton(parent, text='Auto Ducking', variable=self.duck).pack(anchor='w', padx=8, pady=6)
            ttk.Label(parent, text='Música mientras hablas (%)').pack(anchor='w', padx=8)
            ttk.Scale(parent, from_=0, to=100, variable=self.duck_pct).pack(fill='x', padx=8)
            ttk.Button(parent, text='Flotar fondo musical', command=lambda: self.open_module('bg')).pack(fill='x', padx=8, pady=9)
        else:
            ttk.Label(parent, textvariable=self.bg_label, wraplength=320).pack(anchor='w', padx=8, pady=8)
            row = ttk.Frame(parent)
            row.pack(fill='x', padx=8)
            for label, fn in [('Cargar', self.bg_load), ('▶', self.bg_play), ('Ⅱ', self.bg_pause), ('■', self.bg_stop)]:
                ttk.Button(row, text=label, command=fn).pack(side='left', padx=2)
            ttk.Checkbutton(parent, text='Repetir', variable=self.bg_loop).pack(anchor='w', padx=8, pady=5)
            ttk.Checkbutton(parent, text='Reiniciar desde cero', variable=self.bg_restart).pack(anchor='w', padx=8)
            ttk.Checkbutton(parent, text='Auto Ducking del fondo', variable=self.bg_duck).pack(anchor='w', padx=8)
            ttk.Label(parent, text='Volumen del fondo').pack(anchor='w', padx=8, pady=(8, 0))
            self.console_fader(parent, self.bg_volume, 'FADER / PERILLA DIGITAL')
            ttk.Label(parent, text='Volumen al hablar').pack(anchor='w', padx=8)
            ttk.Scale(parent, from_=0, to=100, variable=self.bg_speaking_pct).pack(fill='x', padx=8)

    def setup_decks(self, parent):
        # Cabecera fija; el contenido inferior se desplaza dentro de la pestaña.
        header = ttk.Frame(parent)
        header.pack(fill='x', padx=12, pady=(9, 4))
        ttk.Label(header, text='CABINA VISUAL • DOBLE TORNAMESA').pack(side='left')
        ttk.Label(header, text='Diseño:').pack(side='left', padx=(25, 5))
        for label, value in [('Horizontal', 'horizontal'), ('Vertical', 'vertical')]:
            ttk.Radiobutton(header, text=label, variable=self.deck_orientation,
                            value=value, command=self.deck_relayout).pack(side='left', padx=4)
        modebar = ttk.Frame(parent)
        modebar.pack(fill='x', padx=12, pady=3)
        ttk.Label(modebar, text='Reproducción:').pack(side='left')
        for label, value in [('RADIO (una canción)', 'radio'), ('DJ (mezcla simultánea)', 'dj')]:
            ttk.Radiobutton(modebar, text=label, variable=self.deck_mode, value=value, command=self.change_deck_mode).pack(side='left', padx=7)
        ttk.Checkbutton(modebar, text='Show de luces', variable=self.visual_enabled).pack(side='left', padx=9)
        ttk.Combobox(modebar, textvariable=self.visual_intensity, values=['Suave', 'Normal', 'Espectacular'], state='readonly', width=14).pack(side='left')
        # Área desplazable: mantiene visibles los selectores Radio/DJ y orientación.
        scroll_container = ttk.Frame(parent)
        scroll_container.pack(fill='both', expand=True, padx=(8, 2), pady=(3, 6))
        scroll_canvas = tk.Canvas(scroll_container, bg=BG, highlightthickness=0, borderwidth=0)
        scroll_bar = ttk.Scrollbar(scroll_container, orient='vertical', command=scroll_canvas.yview)
        scroll_canvas.configure(yscrollcommand=scroll_bar.set)
        scroll_bar.pack(side='right', fill='y')
        scroll_canvas.pack(side='left', fill='both', expand=True)
        body = ttk.Frame(scroll_canvas)
        window_id = scroll_canvas.create_window((0, 0), window=body, anchor='nw')
        def refresh_region(event=None):
            scroll_canvas.configure(scrollregion=scroll_canvas.bbox('all'))
        def fit_width(event):
            scroll_canvas.itemconfigure(window_id, width=event.width)
        body.bind('<Configure>', refresh_region)
        scroll_canvas.bind('<Configure>', fit_width)
        def wheel(event):
            if event.delta:
                scroll_canvas.yview_scroll(-int(event.delta / 120) or (-1 if event.delta > 0 else 1), 'units')
            return 'break'
        def wheel_linux_up(event):
            scroll_canvas.yview_scroll(-1, 'units')
            return 'break'
        def wheel_linux_down(event):
            scroll_canvas.yview_scroll(1, 'units')
            return 'break'
        # Registrar rueda solo mientras el puntero esté dentro de esta pestaña.
        def enter(event):
            self.root.bind_all('<MouseWheel>', wheel)
            self.root.bind_all('<Button-4>', wheel_linux_up)
            self.root.bind_all('<Button-5>', wheel_linux_down)
        def leave(event):
            self.root.unbind_all('<MouseWheel>')
            self.root.unbind_all('<Button-4>')
            self.root.unbind_all('<Button-5>')
        scroll_container.bind('<Enter>', enter)
        scroll_container.bind('<Leave>', leave)
        scroll_canvas.bind('<Enter>', enter)
        self.deck_scroll_canvas = scroll_canvas
        self.deck_holder = ttk.Frame(body)
        self.deck_holder.pack(fill='x', padx=12, pady=4)
        for deck in ('A', 'B'):
            area = ttk.LabelFrame(self.deck_holder, text='TORNAMESA ' + deck)
            self.deck_cards[deck] = area
            head = ttk.Frame(area)
            head.pack(fill='x', padx=10, pady=(6, 2))
            ttk.Label(head, textvariable=self.deck_labels[deck], wraplength=460, font=('Segoe UI', 10, 'bold')).pack(side='left', fill='x', expand=True)
            ttk.Label(head, textvariable=self.deck_state_label[deck], foreground='#11a6a2').pack(side='right', padx=8)
            details = ttk.Frame(area)
            details.pack(fill='x', padx=10)
            cover = tk.Canvas(details, width=62, height=62, bg='#102b4b', highlightthickness=0)
            cover.pack(side='left', padx=(0, 10), pady=2)
            cover.create_oval(9, 9, 53, 53, fill='#15517b', outline='#28c8ee', width=2)
            cover.create_oval(27, 27, 35, 35, fill='#07162c', outline='')
            info = ttk.Frame(details)
            info.pack(side='left', fill='x', expand=True)
            ttk.Label(info, textvariable=self.deck_artist[deck]).pack(anchor='w')
            ttk.Label(info, textvariable=self.deck_album[deck]).pack(anchor='w')
            ttk.Label(info, text='Nivel de audio • L / R').pack(anchor='w')
            vu = tk.Canvas(info, height=18, bg='#0b223c', highlightthickness=0)
            vu.pack(fill='x', pady=(2, 2))
            self.deck_vu[deck] = vu
            wave = tk.Canvas(area, height=58, bg='#0c2340', highlightthickness=0)
            wave.pack(fill='x', padx=10, pady=3)
            self.deck_wave[deck] = wave
            selector = ttk.Frame(area)
            selector.pack(fill='x', padx=10, pady=2)
            ttk.Label(selector, text='Visualizador:').pack(side='left')
            ttk.Combobox(selector, textvariable=self.visual_style[deck], state='readonly', width=23,
                         values=['Barras dinámicas', 'Onda real', 'Espectro', 'Ondas circulares', 'Ecualizador arcoíris', 'Luces láser', 'Anillos neón', 'Partículas musicales']).pack(side='left', padx=5)
            bar = ttk.Progressbar(area, orient='horizontal', mode='determinate', maximum=100)
            bar.pack(fill='x', padx=10, pady=3)
            self.deck_progress[deck] = bar
            ttk.Label(area, textvariable=self.deck_time[deck]).pack(anchor='e', padx=10)
            controls = ttk.Frame(area)
            controls.pack(fill='x', padx=5, pady=5)
            for title, fn in [('Cargar', self.deck_load), ('▶', self.deck_play), ('Ⅱ', self.deck_pause), ('■', self.deck_stop)]:
                ttk.Button(controls, text=title, command=lambda d=deck, f=fn: f(d)).pack(side='left', padx=2)
            ttk.Scale(area, from_=0, to=100, variable=self.deck_volume[deck], length=175).pack(fill='x', padx=12, pady=(0, 5))
        self.deck_relayout()
        xf = ttk.LabelFrame(body, text='CROSSFADER • solo modo DJ')
        xf.pack(fill='x', padx=12, pady=3)
        ttk.Label(xf, text='A').pack(side='left', padx=8)
        self.cross_slider = ttk.Scale(xf, from_=0, to=100, variable=self.crossfade)
        self.cross_slider.pack(side='left', fill='x', expand=True, padx=6)
        ttk.Label(xf, text='B').pack(side='left', padx=8)
        self.change_deck_mode()
        ttk.Label(body, textvariable=self.deck_status).pack(anchor='w', padx=18, pady=3)
        bg = ttk.LabelFrame(body, text='FONDO MUSICAL INDEPENDIENTE')
        bg.pack(fill='x', padx=12, pady=4)
        ttk.Label(bg, textvariable=self.bg_label, wraplength=850).pack(anchor='w', padx=10, pady=3)
        controls = ttk.Frame(bg)
        controls.pack(fill='x', padx=8, pady=3)
        for label, command in [('Cargar fondo', self.bg_load), ('▶', self.bg_play), ('Ⅱ', self.bg_pause), ('■', self.bg_stop)]:
            ttk.Button(controls, text=label, command=command).pack(side='left', padx=3)
        ttk.Checkbutton(controls, text='Repetir', variable=self.bg_loop).pack(side='left', padx=5)
        ttk.Checkbutton(controls, text='Reiniciar', variable=self.bg_restart).pack(side='left', padx=5)
        ttk.Checkbutton(controls, text='Auto Ducking', variable=self.bg_duck).pack(side='left', padx=5)
        ttk.Label(bg, text='Fondo al hablar (%)').pack(side='left', padx=12)
        ttk.Scale(bg, from_=0, to=100, variable=self.bg_speaking_pct, length=150).pack(side='left', padx=6)
        ttk.Label(bg, text='Volumen').pack(side='left', padx=6)
        ttk.Scale(bg, from_=0, to=100, variable=self.bg_volume, length=150).pack(side='left', padx=6)
        micbox = ttk.Frame(body)
        micbox.pack(fill='x', padx=12, pady=5)
        ttk.Button(micbox, text='Micrófono F9', command=self.toggle_mute).pack(side='left', padx=6)
        ttk.Label(micbox, textvariable=self.pro_mic_status).pack(side='left', padx=12)
        ttk.Label(micbox, text='Primero: Iniciar audio en CABINA. Audio local, no transmite por Internet.').pack(side='right', padx=8)

    def deck_relayout(self):
        for deck in ('A', 'B'):
            self.deck_cards[deck].pack_forget()
        if self.deck_orientation.get() == 'horizontal':
            for deck in ('A', 'B'):
                self.deck_cards[deck].pack(side='left', fill='both', expand=True, padx=4)
        else:
            for deck in ('A', 'B'):
                self.deck_cards[deck].pack(side='top', fill='x', padx=4, pady=2)
        if hasattr(self, 'deck_scroll_canvas'):
            self.deck_scroll_canvas.yview_moveto(0)

    @staticmethod
    def deck_clock(seconds):
        seconds = max(0, int(seconds))
        return f'{seconds // 60:02d}:{seconds % 60:02d}'

    def change_deck_mode(self):
        if self.deck_mode.get() == 'radio':
            self.cross_slider.state(['disabled'])
            # Conservar solo la tornamesa que se activó más recientemente.
            for d in ('A', 'B'):
                self.deck_running[d] = bool(self.deck_running[d] and d == self.deck_active)
        else:
            self.cross_slider.state(['!disabled'])
        self.deck_playing = any(self.deck_running.values())

    def deck_draw_wave(self, deck):
        canvas = self.deck_wave[deck]
        canvas.delete('all')
        data = self.deck_audio[deck]
        if data is None or len(data) == 0:
            return
        width = max(280, canvas.winfo_width())
        height = 58
        pos = self.deck_pos[deck]
        fraction = min(1.0, pos / len(data))
        style = self.visual_style[deck].get()
        base = '#31d6ff' if deck == 'A' else '#b4a0ff'
        if not self.visual_enabled.get():
            style = 'Onda real'
        intensity = {'Suave': .45, 'Normal': .75, 'Espectacular': 1.0}.get(self.visual_intensity.get(), .75)
        n = 96
        stride = max(1, len(data) // n)
        # Analizar fragmentos espaciados sin recorrer todas las muestras.
        peaks = np.array([float(np.max(np.abs(data[i*stride:min(len(data), i*stride+min(stride, 4096))]))) for i in range(n)])
        peaks /= max(.03, float(np.max(peaks)))
        phase = self.visual_tick * .16
        for i in range(n):
            x = (i+.5) * width/n
            level = float(peaks[i])
            active = self.deck_running[deck]
            pulse = (.6+.4*abs(math.sin(phase+i*.25))) if active else .7
            if style == 'Onda real':
                amp = 3+23*level
                color = '#ff9845' if i/n <= fraction else base
                canvas.create_line(x,29-amp,x,29+amp,fill=color,width=max(1,width/n-1))
            elif style in ('Barras dinámicas','Espectro','Ecualizador arcoíris'):
                amp = (5+46*level*pulse*intensity) if active else 5+32*level
                if style == 'Ecualizador arcoíris':
                    colors = ['#ff3158','#ffad27','#e9f542','#38ec8c','#27bfff','#b67cff']
                    color=colors[(i//16)%6]
                elif style == 'Espectro':
                    color=['#3eff7c','#e8e342','#ff4949'][min(2,int(amp/19))]
                else: color=base
                canvas.create_rectangle(x-1.6,56-amp,x+1.6,56,fill=color,outline='')
            elif style in ('Ondas circulares','Anillos neón'):
                if i >= 72: continue
                angle=i*2*math.pi/72
                r=12+12*level*pulse*intensity
                cx,cy=width/2,29
                color=base if style=='Ondas circulares' else ['#24edff','#ff42e0','#ffe548'][i%3]
                canvas.create_line(cx+16*math.cos(angle),cy+16*math.sin(angle),cx+(16+r)*math.cos(angle),cy+(16+r)*math.sin(angle),fill=color,width=2)
            elif style == 'Luces láser':
                if i%8: continue
                endx=(i*37+int(phase*18))%width
                color=['#f53eaa','#35e8ff','#e6f548','#6aff87'][i%4]
                canvas.create_line(width/2,57,endx,3+12*level,fill=color,width=1+int(intensity*2))
            elif style == 'Partículas musicales':
                xx=(x+phase*(5+i%4))%width if active else x
                yy=29+math.sin(i*.72+phase)*24*level
                color=['#2df4e2','#ed61ff','#ffcb41'][i%3]
                r=1+2*level*intensity
                canvas.create_oval(xx-r,yy-r,xx+r,yy+r,fill=color,outline='')
        canvas.create_line(fraction*width,0,fraction*width,58,fill='#ffffff',width=2)

    def deck_read_metadata(self, deck, path):
        """Etiquetas ID3 opcionales; funciona sin mutagen usando el nombre del archivo."""
        title = os.path.splitext(os.path.basename(path))[0]
        artist, album = 'Desconocido', 'Sin álbum'
        try:
            from mutagen import File
            tags = File(path, easy=True)
            if tags is not None:
                title = (tags.get('title') or [title])[0]
                artist = (tags.get('artist') or [artist])[0]
                album = (tags.get('album') or [album])[0]
        except (ImportError, OSError, ValueError, KeyError, TypeError):
            pass
        self.deck_labels[deck].set(str(title))
        self.deck_artist[deck].set('Artista: ' + str(artist))
        self.deck_album[deck].set('Álbum: ' + str(album))

    def deck_update_vu(self, deck):
        """Nivel de señal de muestras de la pista, ajustado al volumen/crossfader."""
        canvas = self.deck_vu.get(deck)
        if canvas is None:
            return
        canvas.delete('all')
        width = max(100, canvas.winfo_width())
        data = self.deck_audio[deck]
        levels = [0.0, 0.0]
        if self.deck_running[deck] and data is not None and len(data):
            pos = min(self.deck_pos[deck], len(data)-1)
            chunk = data[max(0, pos-2048):min(len(data), pos+2048)]
            if len(chunk):
                gain = self.deck_volume[deck].get()/100.0
                if self.deck_mode.get() == 'dj':
                    x = max(0., min(1., self.crossfade.get()/100.))
                    gain *= math.cos(x*math.pi/2) if deck == 'A' else math.sin(x*math.pi/2)
                levels = [min(1., float(np.sqrt(np.mean(chunk[:, ch]**2)))*3.0*gain) for ch in (0, 1)]
        for ch, level in enumerate(levels):
            y = 1 + ch*9
            canvas.create_rectangle(0,y,width-1,y+7,fill='#142d48',outline='')
            size = int((width-1)*level)
            if size:
                canvas.create_rectangle(0,y,size,y+7,fill=('#32dc91' if level<.65 else '#f2c44d' if level<.9 else '#fa6868'),outline='')

    def deck_refresh_visual(self):
        self.visual_tick += 1
        for deck in ('A', 'B'):
            audio = self.deck_audio[deck]
            if audio is None or not len(audio):
                continue
            duration = len(audio) / RATE
            elapsed = min(self.deck_pos[deck] / RATE, duration)
            remaining = duration-elapsed
            self.deck_time[deck].set(self.deck_clock(elapsed) + ' / ' + self.deck_clock(duration) + '  (-' + self.deck_clock(remaining) + ')')
            self.deck_progress[deck]['value'] = 100 * elapsed / duration if duration else 0
            if deck in self.unified_deck_progress:
                self.unified_deck_progress[deck]['value'] = 100 * elapsed / duration if duration else 0
            self.deck_state_label[deck].set('EN REPRODUCCIÓN' if self.deck_running[deck] else 'EN ESPERA')
            self.deck_update_vu(deck)
            # Actualización visual reducida para ahorrar CPU.
            if self.visual_tick % 3 == 0:
                self.deck_draw_wave(deck)
                if deck in self.unified_deck_wave:
                    original = self.deck_wave[deck]
                    try:
                        self.deck_wave[deck] = self.unified_deck_wave[deck]
                        self.deck_draw_wave(deck)
                    finally:
                        self.deck_wave[deck] = original

    def deck_load(self, deck):
        path = filedialog.askopenfilename(title='Cargar tornamesa ' + deck, filetypes=[('Audio', '*.mp3 *.wav')])
        if not path:
            return
        try:
            data = self.decode_local_audio(path)
        except Exception as exc:
            messagebox.showerror('Tornamesa', str(exc))
            return
        if self.deck_active == deck:
            self.deck_running[deck] = False
            self.deck_playing = any(self.deck_running.values())
            self.deck_active = None
        self.deck_files[deck] = path
        self.deck_audio[deck] = data
        self.deck_pos[deck] = 0
        self.deck_labels[deck].set(os.path.basename(path))
        self.deck_read_metadata(deck, path)
        self.deck_draw_wave(deck)

    def deck_play(self, deck):
        if self.deck_audio[deck] is None:
            self.deck_load(deck)
        if self.deck_audio[deck] is None:
            return
        if self.deck_pos[deck] >= len(self.deck_audio[deck]):
            self.deck_pos[deck] = 0
        if self.deck_mode.get() == 'radio':
            other = 'B' if deck == 'A' else 'A'
            self.deck_running[other] = False
            self.deck_pos[other] = 0
        self.deck_active = deck
        self.deck_running[deck] = True
        self.deck_playing = True
        self.playing = False
        self.deck_status.set('Modo ' + self.deck_mode.get().upper() + ' • reproduciendo tornamesa ' + deck)

    def deck_pause(self, deck):
        self.deck_running[deck] = False
        self.deck_playing = any(self.deck_running.values())
        self.deck_status.set('Tornamesa ' + deck + ' pausada')

    def deck_stop(self, deck):
        self.deck_running[deck] = False
        self.deck_playing = any(self.deck_running.values())
        self.deck_pos[deck] = 0
        self.deck_status.set('Tornamesa ' + deck + ' detenida')

    def bg_load(self):
        path = filedialog.askopenfilename(title='Cargar música de fondo', filetypes=[('Audio', '*.mp3 *.wav')])
        if not path:
            return
        try:
            data = self.decode_local_audio(path)
        except Exception as exc:
            messagebox.showerror('Fondo musical', str(exc))
            return
        self.bg_playing = False
        self.bg_fade_samples = 0
        self.bg_was_blocked = False
        self.bg_audio = data
        self.bg_path = path
        self.bg_pos = 0
        self.bg_label.set(os.path.basename(path))
        self.bg_status.set('Fondo cargado')

    def bg_play(self):
        if self.bg_audio is None:
            self.bg_load()
        if self.bg_audio is not None:
            if self.bg_pos >= len(self.bg_audio):
                self.bg_pos = 0
            self.bg_playing = True
            self.bg_fade_samples = 0
            self.bg_status.set('Fondo activo • se pausa automáticamente durante canciones')

    def bg_pause(self):
        self.bg_playing = False
        self.bg_status.set('Fondo pausado')

    def bg_stop(self):
        self.bg_playing = False
        self.bg_pos = 0
        self.bg_fade_samples = 0
        self.bg_was_blocked = False
        self.bg_status.set('Fondo detenido')

    def library_connect(self):
        os.makedirs(os.path.dirname(self.library_db), exist_ok=True)
        conn = sqlite3.connect(self.library_db, timeout=20)
        conn.execute('PRAGMA busy_timeout=20000')
        return conn

    def library_init(self):
        with self.library_connect() as db:
            db.execute('CREATE TABLE IF NOT EXISTS folders (path TEXT PRIMARY KEY)')
            db.execute('CREATE TABLE IF NOT EXISTS songs (path TEXT PRIMARY KEY, name TEXT NOT NULL, folder TEXT NOT NULL)')
            db.execute('CREATE INDEX IF NOT EXISTS songs_name_idx ON songs(name)')

    def library_choose_folder(self):
        folder = filedialog.askdirectory(title='Importar carpeta a la biblioteca (incluye subcarpetas)')
        if folder:
            self.library_start_scan([os.path.abspath(folder)], register=True)

    def library_rescan(self):
        with self.library_connect() as db:
            folders = [r[0] for r in db.execute('SELECT path FROM folders ORDER BY path')]
        if not folders:
            messagebox.showinfo('Biblioteca', 'Importa primero una carpeta de música.')
            return
        self.library_start_scan(folders, register=False)

    def library_show_folders(self):
        with self.library_connect() as db:
            folders = [r[0] for r in db.execute('SELECT path FROM folders ORDER BY path')]
        messagebox.showinfo('Carpetas registradas', '\n'.join(folders) if folders else 'Todavía no hay carpetas registradas.')

    def library_start_scan(self, folders, register):
        if self.library_scan_running:
            messagebox.showinfo('Biblioteca', 'Ya se está revisando una carpeta. Espera a que termine.')
            return
        self.library_scan_running = True
        self.library_status.set('Revisando archivos en segundo plano…')
        threading.Thread(target=self.library_scan_worker, args=(folders, register), daemon=True).start()

    def library_scan_worker(self, folders, register):
        added = 0
        missing = []
        try:
            with self.library_connect() as db:
                for folder in folders:
                    if not os.path.isdir(folder):
                        missing.append(folder)
                        continue
                    if register:
                        db.execute('INSERT OR IGNORE INTO folders(path) VALUES (?)', (folder,))
                    batch = []
                    for base, dirs, files in os.walk(folder):
                        dirs.sort(key=str.casefold)
                        for name in files:
                            if name.lower().endswith(('.mp3', '.wav')):
                                path = os.path.abspath(os.path.join(base, name))
                                batch.append((path, name, folder))
                                if len(batch) >= 400:
                                    db.executemany('INSERT OR REPLACE INTO songs(path,name,folder) VALUES (?,?,?)', batch)
                                    added += len(batch)
                                    batch.clear()
                    if batch:
                        db.executemany('INSERT OR REPLACE INTO songs(path,name,folder) VALUES (?,?,?)', batch)
                        added += len(batch)
            self.library_events.put(('done', added, missing))
        except Exception as exc:
            self.library_events.put(('error', str(exc)))

    def library_schedule_search(self, *_):
        if self.library_search_job is not None:
            self.root.after_cancel(self.library_search_job)
        self.library_search_job = self.root.after(250, self.library_search)

    def library_search(self):
        self.library_search_job = None
        try:
            q = self.library_query.get().strip().casefold()
            with self.library_connect() as db:
                if q:
                    # Búsqueda literal (no patrones SQL) en nombre o ruta.
                    rows = db.execute('SELECT path,name FROM songs WHERE instr(lower(name), ?) > 0 OR instr(lower(path), ?) > 0 ORDER BY name COLLATE NOCASE LIMIT 500', (q, q)).fetchall()
                else:
                    rows = db.execute('SELECT path,name FROM songs ORDER BY name COLLATE NOCASE LIMIT 500').fetchall()
                total = db.execute('SELECT COUNT(*) FROM songs').fetchone()[0]
            self.library_results = rows
            self.library_listbox.delete(0, 'end')
            for path, name in rows:
                self.library_listbox.insert('end', ('● ' if os.path.isfile(path) else '⚠ NO DISPONIBLE • ') + name + '  —  ' + os.path.dirname(path))
            self.library_status.set(f'{total} canciones catalogadas • {len(rows)} resultados visibles. Selecciona y añade a CABINA.')
        except Exception as exc:
            self.library_status.set('Error de biblioteca: ' + str(exc))

    def library_add_paths(self, paths):
        known = {os.path.normcase(os.path.abspath(p)) for p in self.tracks}
        added = 0
        unavailable = 0
        for path in paths:
            if not os.path.isfile(path):
                unavailable += 1
                continue
            key = os.path.normcase(os.path.abspath(path))
            if key not in known:
                known.add(key)
                self.tracks.append(path)
                self.listbox.insert('end', os.path.basename(path))
                added += 1
        self.status.set(f'Biblioteca: {added} canciones añadidas a CABINA; {unavailable} archivos no disponibles. Guarda la lista.')
        self.library_status.set(f'{added} añadidas a CABINA; {unavailable} no disponibles. Usa Guardar lista en CABINA.')

    def library_add_selected(self):
        indices = self.library_listbox.curselection()
        if not indices:
            messagebox.showinfo('Biblioteca', 'Selecciona una o varias canciones primero.')
            return
        self.library_add_paths([self.library_results[i][0] for i in indices])

    def library_add_visible(self):
        if len(self.library_results) > 500:
            return
        if not self.library_results:
            messagebox.showinfo('Biblioteca', 'No hay resultados para añadir.')
            return
        self.library_add_paths([p for p, _ in self.library_results])

    def library_process_events(self):
        try:
            while True:
                event = self.library_events.get_nowait()
                self.library_scan_running = False
                if event[0] == 'done':
                    _, count, missing = event
                    self.library_search()
                    suffix = (' Carpetas sin conexión: ' + '; '.join(missing[:3])) if missing else ''
                    self.library_status.set(f'Revisión finalizada: {count} archivos encontrados.' + suffix)
                else:
                    self.library_status.set('Error al importar: ' + event[1])
        except queue.Empty:
            pass

    def numeric_scale(self, parent, name, variable, low, high, unit='', signed=False):
        """Perilla giratoria real vinculada a la variable original de audio.

        Arrastrar verticalmente, rueda o flechas del teclado ajusta el valor.
        No duplica el motor ni reemplaza el procesamiento de sonido.
        """
        panel = tk.Frame(parent, bg='#102035', highlightbackground='#34536b', highlightthickness=1)
        panel.pack(anchor='w', padx=20, pady=7, fill='x')
        tk.Label(panel, text=name, bg='#102035', fg='#e8f4ff',
                 font=('Segoe UI', 10, 'bold'), anchor='w').pack(side='left', padx=12, fill='x', expand=True)
        knob = tk.Canvas(panel, width=106, height=100, bg='#102035', highlightthickness=0,
                         cursor='hand2', takefocus=1)
        knob.pack(side='right', padx=12, pady=5)
        span = high - low
        def draw(*_):
            try:
                v = max(low, min(high, float(variable.get())))
                fraction = (v-low)/span
                knob.delete('all')
                knob.create_arc(10, 6, 96, 92, start=225, extent=-270,
                                style='arc', outline='#3b526a', width=8)
                if fraction > 0:
                    knob.create_arc(10, 6, 96, 92, start=225, extent=-270*fraction,
                                    style='arc', outline='#2fd8fa', width=8)
                knob.create_oval(21, 17, 85, 81, fill='#24364b', outline='#6d8298', width=2)
                angle = math.radians(225-270*fraction)
                cx,cy=53,49
                knob.create_line(cx+17*math.cos(angle),cy-17*math.sin(angle),
                                 cx+27*math.cos(angle),cy-27*math.sin(angle),
                                 fill='#2fd8fa',width=5,capstyle='round')
                formatted = f'{round(v):+d}' if signed else f'{round(v):d}'
                knob.create_text(53, 51, text=formatted, fill='white',font=('Segoe UI', 13, 'bold'))
                knob.create_text(53, 96, text=unit.strip(), fill='#a7bed2',font=('Segoe UI', 8))
            except (tk.TclError, ValueError):
                pass
        def adjust(delta):
            try: variable.set(max(low, min(high, round(variable.get()+delta))))
            except tk.TclError: pass
        def press(event):
            knob.focus_set()
            knob._drag_y = event.y
            knob._drag_value = float(variable.get())
        def drag(event):
            if hasattr(knob,'_drag_y'):
                change = (knob._drag_y-event.y)*span/170
                variable.set(max(low,min(high,round(knob._drag_value+change))))
        knob.bind('<ButtonPress-1>',press)
        knob.bind('<B1-Motion>',drag)
        knob.bind('<MouseWheel>',lambda e:adjust((1 if e.delta>0 else -1)*max(1,round(span/100))))
        knob.bind('<Button-4>',lambda e:adjust(max(1,round(span/100))))
        knob.bind('<Button-5>',lambda e:adjust(-max(1,round(span/100))))
        knob.bind('<Left>',lambda e:adjust(-1))
        knob.bind('<Down>',lambda e:adjust(-1))
        knob.bind('<Right>',lambda e:adjust(1))
        knob.bind('<Up>',lambda e:adjust(1))
        variable.trace_add('write',draw)
        draw()
        return panel

    def eq_scale(self, parent, name, variable):
        self.numeric_scale(parent, name, variable, -12, 12, ' dB', signed=True)

    def scale(self, parent, name, variable):
        self.numeric_scale(parent, name, variable, 0, 100, ' %')

    def reset_effects(self):
        self.noise_filter.set(True)
        self.noise_gate.set(18)
        self.eq_enabled.set(True)
        self.eq_low.set(0)
        self.eq_mid.set(0)
        self.eq_high.set(0)
        self.compress.set(False)
        self.echo_pct.set(0)
        self.status.set('Efectos restablecidos: EQ neutro, eco 0 %, ruido 18 %.')

    def detect(self):
        try:
            all_devices = sd.query_devices()
            self.devices = [(i, d['name']) for i, d in enumerate(all_devices) if d['max_input_channels'] >= 1]
            self.output_devices = [(i, d['name']) for i, d in enumerate(all_devices) if d['max_output_channels'] >= 2]
            if self.output_name.get() != 'Predeterminada de Windows' and self.output_name.get() not in [f'{i}: {name}' for i, name in self.output_devices]:
                self.output_name.set('Predeterminada de Windows')
            device_values = [f'{i}: {name}' for i, name in self.devices]
            self.combo['values'] = device_values
            for modular_combo in self.modular_mic_combos:
                try:
                    if modular_combo.winfo_exists():
                        modular_combo['values'] = device_values
                except tk.TclError:
                    pass
            if self.devices:
                if self.device_name.get() not in device_values:
                    self.combo.current(0)
            else:
                self.device_name.set('')
        except Exception as exc:
            messagebox.showerror('Micrófono', str(exc))

    def toggle_mute(self, event=None):
        self.mic_muted = not self.mic_muted
        self.pro_mic_status.set('MICRÓFONO SILENCIADO • F9' if self.mic_muted else 'MICRÓFONO ACTIVO • F9')
        if self.mic_muted:
            self.talking = False
            self.silence_blocks = 0
            self.duck_factor = 1.0
            self.mute_button.config(text='🔇 MICRÓFONO SILENCIADO  •  F9', bg='#b33644')
            self.mute_label.config(text='La voz NO entra en la mezcla ni en la grabación.')
            self.meter.set(0)
            self.status.set('Micrófono silenciado. La música continúa.')
        else:
            self.mute_button.config(text='🎙 MICRÓFONO ACTIVO  •  F9', bg='#18794e')
            self.mute_label.config(text='Micrófono abierto: voz y Auto Ducking disponibles.')
            self.status.set('Micrófono activado. Usa audífonos para evitar eco.')

    def add(self):
        paths = filedialog.askopenfilenames(filetypes=[('Audio MP3 o WAV', '*.mp3 *.wav')])
        for path in paths:
            self.tracks.append(path)
            self.listbox.insert('end', os.path.basename(path))

    def add_folder(self):
        folder = filedialog.askdirectory(title='Selecciona la carpeta de música')
        if not folder:
            return
        known = {os.path.normcase(os.path.abspath(p)) for p in self.tracks}
        added = 0
        for root_dir, dirs, files in os.walk(folder):
            dirs.sort(key=str.casefold)
            for filename in sorted(files, key=str.casefold):
                if not filename.lower().endswith(('.mp3', '.wav')):
                    continue
                path = os.path.abspath(os.path.join(root_dir, filename))
                key = os.path.normcase(path)
                if key in known:
                    continue
                known.add(key)
                self.tracks.append(path)
                self.listbox.insert('end', os.path.basename(path))
                added += 1
        self.status.set(f'Carpeta importada: {added} canciones nuevas. Total: {len(self.tracks)}. Guarda la lista para conservarla.')
        messagebox.showinfo('Importación completa', f'Se añadieron {added} archivos MP3/WAV.\nTambién se revisaron las subcarpetas.\nLos archivos originales no se modificaron.')

    def save_playlist_as(self):
        path = filedialog.asksaveasfilename(defaultextension='.json', filetypes=[('Lista Coca Studio', '*.json')], initialfile='Mi_programacion.json')
        if not path:
            return
        try:
            with open(path, 'w', encoding='utf-8') as f:
                json.dump({'tracks': self.tracks, 'shuffle': self.shuffle_mode.get()}, f, ensure_ascii=False, indent=2)
            self.status.set('Programación guardada en ' + path)
        except Exception as exc:
            messagebox.showerror('Guardar programación', str(exc))

    def choose_hour_folder(self):
        folder = filedialog.askdirectory(title='Selecciona tus locuciones horarias')
        if folder:
            self.hour_folder.set(folder)
            self.hour_status.set('Carpeta seleccionada. Usa HH-MM.mp3 o HH-MM.wav; ejemplo 14-30.mp3.')

    def load_hour_recording(self, moment):
        folder = self.hour_folder.get()
        if not folder or not os.path.isdir(folder):
            return None
        stem = moment.strftime('%H-%M')
        for ext in ('.wav', '.mp3'):
            path = os.path.join(folder, stem + ext)
            if os.path.isfile(path):
                data, rate = sf.read(path, dtype='float32', always_2d=True)
                if rate != RATE:
                    divisor = math.gcd(rate, RATE)
                    data = resample_poly(data, RATE // divisor, rate // divisor, axis=0).astype('float32')
                if data.shape[1] == 1:
                    data = np.repeat(data, 2, axis=1)
                return data[:, :2]
        return None

    def import_jingles(self):
        folder = filedialog.askdirectory(title='Selecciona la carpeta de jingles')
        if not folder:
            return
        known = {os.path.normcase(os.path.abspath(p)) for p in self.jingle_paths}
        added = 0
        for folder_path, dirs, files in os.walk(folder):
            dirs.sort(key=str.casefold)
            for filename in sorted(files, key=str.casefold):
                if not filename.lower().endswith(('.mp3', '.wav')):
                    continue
                path = os.path.abspath(os.path.join(folder_path, filename))
                if os.path.normcase(path) not in known:
                    self.jingle_paths.append(path)
                    self.jingle_listbox.insert('end', filename)
                    known.add(os.path.normcase(path))
                    added += 1
        self.jingle_status.set(f'{added} jingles nuevos; total {len(self.jingle_paths)}. Archivos originales sin cambios.')

    def start_jingle(self, path, automatic=False):
        if self.jingle_audio is not None:
            self.jingle_status.set('Ya hay un jingle reproduciéndose.')
            return False
        try:
            data, rate = sf.read(path, dtype='float32', always_2d=True)
            if rate != RATE:
                divisor = math.gcd(rate, RATE)
                data = resample_poly(data, RATE // divisor, rate // divisor, axis=0).astype('float32')
            if data.shape[1] == 1:
                data = np.repeat(data, 2, axis=1)
            if not len(data):
                raise ValueError('El archivo está vacío.')
            self.jingle_audio = data[:, :2]
            self.jingle_pos = 0
            self.resume_after_jingle = automatic
            self.jingle_status.set('Reproduciendo: ' + os.path.basename(path))
            return True
        except Exception as exc:
            self.jingle_status.set('Error al abrir jingle: ' + str(exc))
            return False

    def play_jingle_manual(self):
        if not self.jingle_paths:
            messagebox.showinfo('Jingles', 'Primero importa una carpeta de jingles.')
            return
        selected = self.jingle_listbox.curselection()
        idx = selected[0] if selected else self.jingle_cursor % len(self.jingle_paths)
        if self.start_jingle(self.jingle_paths[idx]):
            self.jingle_cursor = idx + 1

    def play_next_jingle(self):
        if not self.jingle_paths:
            return False
        for _ in range(len(self.jingle_paths)):
            idx = self.jingle_cursor % len(self.jingle_paths)
            self.jingle_cursor += 1
            if self.start_jingle(self.jingle_paths[idx], automatic=True):
                return True
        return False

    def play(self):
        if not self.tracks:
            messagebox.showinfo('Música', 'Añade primero un archivo MP3 o WAV.')
            return
        idx = self.listbox.curselection()[0] if self.listbox.curselection() else (self.current_idx if self.current_idx is not None and self.current_idx < len(self.tracks) else 0)
        self.play_index(idx)

    def play_index(self, idx):
        try:
            while True:
                self.track_finished.get_nowait()
        except queue.Empty:
            pass
        if not self.tracks or idx < 0 or idx >= len(self.tracks):
            return
        try:
            # soundfile utiliza libsndfile; MP3 requiere soporte de este formato.
            data, rate = sf.read(self.tracks[idx], dtype='float32', always_2d=True)
            if rate != RATE:
                # Conversión de frecuencia de alta calidad antes de la reproducción.
                divisor = math.gcd(rate, RATE)
                data = resample_poly(data, RATE // divisor, rate // divisor, axis=0).astype('float32')
            if data.shape[1] == 1:
                data = np.repeat(data, 2, axis=1)
            else:
                data = data[:, :2]
            self.deck_playing = False
            self.deck_running = {'A': False, 'B': False}
            self.deck_active = None
            self.audio = data
            self.current_idx = idx
            self.listbox.selection_clear(0, 'end')
            self.listbox.selection_set(idx)
            self.listbox.see(idx)
            self.pos = 0
            self.playing = True
            self.status.set('Reproduciendo: ' + os.path.basename(self.tracks[idx]) + (f' • convertido de {rate} Hz a {RATE} Hz' if rate != RATE else ''))
        except Exception as exc:
            messagebox.showerror('Abrir audio', f'No se pudo leer el archivo: {exc}')

    def toggle_mode(self):
        enabled = not self.auto_mode.get()
        self.auto_mode.set(enabled)
        self.mode_button.config(text='MODO AUTOMÁTICO' if enabled else 'MODO MANUAL', bg='#18794e' if enabled else '#b36b28')
        self.status.set('Automatización local activada: avanzará entre canciones.' if enabled else 'Modo manual activado.')

    def next_track(self):
        if not self.tracks:
            return
        if self.shuffle_mode.get() and len(self.tracks) > 1:
            choices = [i for i in range(len(self.tracks)) if i != self.current_idx]
            idx = random.choice(choices)
        else:
            idx = (self.current_idx + 1) % len(self.tracks) if self.current_idx is not None else 0
        self.play_index(idx)

    def remove_selected(self):
        selected = self.listbox.curselection()
        if not selected:
            return
        idx = selected[0]
        self.tracks.pop(idx)
        self.listbox.delete(idx)
        if self.current_idx == idx:
            self.playing = False
            self.audio = None
            self.current_idx = None
        elif self.current_idx is not None and self.current_idx > idx:
            self.current_idx -= 1

    def save_playlist(self):
        try:
            os.makedirs(os.path.dirname(self.playlist_path), exist_ok=True)
            with open(self.playlist_path, 'w', encoding='utf-8') as f:
                json.dump({'tracks': self.tracks, 'shuffle': self.shuffle_mode.get()}, f, ensure_ascii=False, indent=2)
            self.status.set('Lista guardada en ' + self.playlist_path)
        except Exception as exc:
            messagebox.showerror('Guardar lista', str(exc))

    def load_default_playlist(self):
        if os.path.isfile(self.playlist_path):
            self.load_playlist(self.playlist_path, quiet=True)

    def load_playlist_dialog(self):
        path = filedialog.askopenfilename(filetypes=[('Lista Coca Studio', '*.json')])
        if path:
            self.load_playlist(path)

    def load_playlist(self, path, quiet=False):
        try:
            with open(path, encoding='utf-8') as f:
                data = json.load(f)
            paths = data.get('tracks', [])
            if not isinstance(paths, list) or not all(isinstance(p, str) for p in paths):
                raise ValueError('Formato de lista inválido')
            available = [p for p in paths if os.path.isfile(p)]
            self.playing = False
            self.audio = None
            self.current_idx = None
            self.tracks = available
            self.listbox.delete(0, 'end')
            for p in available:
                self.listbox.insert('end', os.path.basename(p))
            self.shuffle_mode.set(bool(data.get('shuffle', False)))
            if not quiet:
                self.status.set(f'Lista cargada: {len(available)} canciones. {len(paths)-len(available)} archivos no encontrados.')
        except Exception as exc:
            if not quiet:
                messagebox.showerror('Cargar lista', str(exc))

    def pause(self):
        self.playing = not self.playing if self.audio is not None else False
        self.status.set('Música reanudada' if self.playing else 'Música pausada')

    def stop(self):
        self.playing = False
        # Vaciar señales pendientes para evitar saltos inesperados al detener.
        try:
            while True:
                self.track_finished.get_nowait()
        except queue.Empty:
            pass
        self.pos = 0
        self.status.set('Música detenida')

    def start_audio(self):
        if self.stream is not None:
            return
        idx = self.combo.current()
        if idx < 0:
            messagebox.showinfo('Micrófono', 'Selecciona un micrófono.')
            return
        try:
            output_idx = None
            if self.output_name.get() != 'Predeterminada de Windows':
                output_idx = int(self.output_name.get().split(':', 1)[0])
            self.stream = sd.Stream(device=(self.devices[idx][0], output_idx), samplerate=RATE,
                                    channels=(1, 2), blocksize=BLOCK, dtype='float32',
                                    callback=self.callback)
            self.hp_state.fill(0)
            self.gate_envelope = 0.0
            self.eq_states = [None, None, None]
            self.echo_buffer.fill(0)
            self.echo_index = 0
            self.stream.start()
            self.status.set('Audio iniciado. Usa audífonos para evitar eco.')
        except Exception as exc:
            if self.stream:
                self.stream.close()
                self.stream = None
            messagebox.showerror('Dispositivo de audio', str(exc))

    def callback(self, indata, outdata, frames, time_info, status):
        # El MUTE elimina la voz de la mezcla, la grabación y el detector de ducking.
        raw_input = float(np.sqrt(np.mean(indata[:, 0] ** 2))) if frames else 0.0
        try:
            self.input_meter_queue.put_nowait(raw_input)
        except queue.Full:
            pass
        voice = indata[:, 0].copy() if not self.mic_muted else np.zeros(frames, dtype='float32')
        if self.noise_filter.get():
            # Paso alto contra vibraciones y graves; puerta suave contra ruido en pausas.
            filtered, self.hp_state = sosfilt(self.hp_sos, voice, zi=self.hp_state)
            voice = filtered.astype('float32')
            raw_rms = float(np.sqrt(np.mean(voice * voice)))
            # 0% = umbral bajo, 100% = umbral alto.
            threshold = 0.002 + (self.noise_gate.get() / 100) * 0.035
            target_gate = 1.0 if raw_rms >= threshold else 0.0
            # Apertura rápida, cierre gradual; evita cortes secos entre palabras.
            speed = 0.65 if target_gate else 0.055
            self.gate_envelope += (target_gate - self.gate_envelope) * speed
            voice *= self.gate_envelope
        else:
            self.gate_envelope = 1.0
        # Ecualizador: tres filtros shelf/peak con ganancias moderadas.
        if self.eq_enabled.get() and not self.mic_muted:
            for j, (kind, hz, gain) in enumerate((('low', 180, self.eq_low.get()), ('mid', 1300, self.eq_mid.get()), ('high', 4200, self.eq_high.get()))):
                if abs(gain) < 0.1:
                    continue
                # Aproximación estable: realce/atenuación mediante mezcla con banda filtrada.
                if kind == 'low':
                    sos = butter(2, hz, btype='lowpass', fs=RATE, output='sos')
                elif kind == 'high':
                    sos = butter(2, hz, btype='highpass', fs=RATE, output='sos')
                else:
                    from scipy.signal import iirpeak, tf2sos
                    bb, aa = iirpeak(hz, 0.8, fs=RATE)
                    sos = tf2sos(bb, aa)
                state = self.eq_states[j]
                if state is None:
                    state = np.zeros((len(sos), 2))
                band, self.eq_states[j] = sosfilt(sos, voice, zi=state)
                voice = (voice + band.astype('float32') * (gain / 18.0)).astype('float32')
        if self.compress.get():
            voice = np.tanh(voice * 1.8).astype('float32') / np.tanh(1.8)
        echo_mix = self.echo_pct.get() / 100
        if echo_mix > 0 and not self.mic_muted:
            # Retardo de 240 ms, con memoria continua entre bloques.
            delayed = np.empty_like(voice)
            for k in range(len(voice)):
                delayed[k] = self.echo_buffer[self.echo_index]
                self.echo_buffer[self.echo_index] = voice[k] + delayed[k] * 0.20
                self.echo_index = (self.echo_index + 1) % len(self.echo_buffer)
            voice = (voice + delayed * echo_mix * 0.5).astype('float32')
        elif self.mic_muted:
            self.echo_buffer.fill(0)
        rms = float(np.sqrt(np.mean(voice * voice)))
        if not self.mic_muted and rms > 0.025:
            self.talking = True
            self.silence_blocks = 0
        else:
            self.silence_blocks += 1
            if self.silence_blocks > 15:
                self.talking = False
        target = self.duck_pct.get() / 100 if self.duck.get() and self.talking and not self.mic_muted else 1.0
        # Suavizado según duración real de bloque, independiente del tamaño de buffer.
        transition_ms = self.duck_attack.get() if target < self.duck_factor else self.duck_release.get()
        alpha = 1.0 - math.exp(-(frames / RATE) / max(0.001, transition_ms / 1000.0))
        self.duck_factor += (target - self.duck_factor) * alpha
        try:
            self.duck_events.put_nowait((bool(self.talking and not self.mic_muted), float(self.duck_factor), bool(self.duck.get()), self.stream is not None))
        except queue.Full:
            pass
        music = np.zeros((frames, 2), dtype='float32')
        if self.playing and self.audio is not None:
            end = min(self.pos + frames, len(self.audio))
            length = end - self.pos
            if length > 0:
                music[:length] = self.audio[self.pos:end]
            self.pos = end
            if end >= len(self.audio):
                self.playing = False
                if self.auto_mode.get():
                    try:
                        self.track_finished.put_nowait(True)
                    except queue.Full:
                        pass
        channel_audio = {'DECK A': np.zeros((frames, 2), dtype='float32'),
                         'DECK B': np.zeros((frames, 2), dtype='float32')}
        deck_was_playing = any(self.deck_running.values())
        # En DJ ambas tornamesas se mezclan con crossfader de potencia constante.
        if deck_was_playing:
            xf = max(0.0, min(1.0, self.crossfade.get()/100))
            gains = {'A': math.cos(xf*math.pi/2), 'B': math.sin(xf*math.pi/2)} if self.deck_mode.get() == 'dj' else {'A': 1.0, 'B': 1.0}
            music[:] = 0
            for deck in ('A', 'B'):
                if not self.deck_running[deck]:
                    continue
                data = self.deck_audio[deck]
                if data is None:
                    self.deck_running[deck] = False
                    continue
                start = self.deck_pos[deck]
                count = min(frames, max(0, len(data)-start))
                if count:
                    contribution = data[start:start+count] * (self.deck_volume[deck].get()/100) * gains[deck]
                    music[:count] += contribution
                    channel_audio['DECK ' + deck][:count] = contribution
                    self.deck_pos[deck] += count
                if self.deck_pos[deck] >= len(data):
                    self.deck_running[deck] = False
            self.deck_playing = any(self.deck_running.values())
        # La cabina o un deck bloquean el fondo, pero el micrófono no.
        # La transición de desbloqueo reinicia el fondo y aplica fade-in de 2 s.
        blocked = bool(self.playing or deck_was_playing)
        if blocked and not self.bg_was_blocked:
            self.bg_was_blocked = True
        elif not blocked and self.bg_was_blocked:
            self.bg_was_blocked = False
            if self.bg_restart.get():
                self.bg_pos = 0
            self.bg_fade_samples = 0
        background = np.zeros((frames, 2), dtype='float32')
        if self.bg_playing and self.bg_audio is not None and not blocked:
            total = len(self.bg_audio)
            if total:
                copied = 0
                while copied < frames:
                    remaining = total - self.bg_pos
                    count = min(frames - copied, remaining)
                    if count > 0:
                        background[copied:copied + count] = self.bg_audio[self.bg_pos:self.bg_pos + count]
                        copied += count
                        self.bg_pos += count
                    if self.bg_pos >= total:
                        if self.bg_loop.get():
                            self.bg_pos = 0
                        else:
                            self.bg_playing = False
                            break
                # Entrada suave en los primeros dos segundos del fondo.
                fade = np.clip((np.arange(frames) + self.bg_fade_samples) / (2.0 * RATE), 0, 1)
                background *= fade[:, None]
                self.bg_fade_samples = min(2 * RATE, self.bg_fade_samples + frames)
        # El ducking existente detecta la voz; se aplica por separado al fondo.
        voice_reduction = min(1.0, max(0.0, self.bg_speaking_pct.get() / 100.0))
        bg_target = voice_reduction if self.bg_duck.get() else 1.0
        bg_duck_gain = 1.0 - (1.0 - bg_target) * (1.0 - self.duck_factor)
        # El detector de voz debe funcionar aunque se desactive el ducking general.
        if self.bg_duck.get() and not self.duck.get() and self.talking and not self.mic_muted:
            bg_duck_gain = bg_target
        background *= (self.bg_volume.get() / 100) * bg_duck_gain
        # Locución horaria superpuesta a la mezcla, con atenuación de música.
        announcement = np.zeros((frames, 2), dtype='float32')
        if self.announcement_audio is not None:
            remain = len(self.announcement_audio) - self.announcement_pos
            count = min(frames, max(0, remain))
            if count:
                announcement[:count] = self.announcement_audio[self.announcement_pos:self.announcement_pos + count]
                self.announcement_pos += count
            if self.announcement_pos >= len(self.announcement_audio):
                self.announcement_audio = None
                self.announcement_pos = 0
        music *= (self.music_vol.get() / 100) * self.duck_factor
        if np.any(announcement):
            music *= 0.20
        jingle = np.zeros((frames, 2), dtype='float32')
        if self.jingle_audio is not None:
            remaining = len(self.jingle_audio) - self.jingle_pos
            count = min(frames, max(0, remaining))
            if count:
                jingle[:count] = self.jingle_audio[self.jingle_pos:self.jingle_pos + count]
                self.jingle_pos += count
            if self.jingle_pos >= len(self.jingle_audio):
                self.jingle_audio = None
                self.jingle_pos = 0
                if self.resume_after_jingle:
                    self.resume_after_jingle = False
                    try:
                        self.jingle_finished.put_nowait(True)
                    except queue.Full:
                        pass
        if np.any(jingle):
            music *= 0.25
        jingle *= self.jingle_volume.get() / 100
        mic = voice[:, None] * (self.mic_vol.get() / 100)
        # Captura de nivel por bloque DESPUÉS de volumen y ducking; sin animación ficticia.
        # Deck y fondo están en silencio cuando sus reproductores están detenidos.
        def stereo_rms(buffer):
            if buffer.size == 0:
                return (0.0, 0.0)
            if buffer.shape[1] == 1:
                val = float(np.sqrt(np.mean(buffer[:, 0] ** 2)))
                return (val, val)
            result = np.sqrt(np.mean(buffer ** 2, axis=0))
            return (float(result[0]), float(result[1]))
        channel_levels = {
            'MIC 1': stereo_rms(mic),
            'DECK A': stereo_rms(channel_audio['DECK A'] * (self.music_vol.get()/100) * self.duck_factor),
            'DECK B': stereo_rms(channel_audio['DECK B'] * (self.music_vol.get()/100) * self.duck_factor),
            'FONDO': stereo_rms(background),
            'MÚSICA': stereo_rms(music),
        }
        try:
            self.channel_meter_queue.put_nowait(channel_levels)
        except queue.Full:
            pass
        mix = np.clip(music + background + mic + announcement * 0.75 + jingle, -0.95, 0.95)
        outdata[:] = mix if self.monitor.get() else np.clip(music + background + announcement * 0.75 + jingle, -0.95, 0.95)
        try:
            levels = np.sqrt(np.mean(outdata * outdata, axis=0))
            self.output_meter_queue.put_nowait((float(levels[0]), float(levels[1])))
        except queue.Full:
            pass
        if self.recording:
            try:
                self.write_queue.put_nowait((mix * 32767).astype('<i2').tobytes())
            except queue.Full:
                pass
        try:
            self.meter_queue.put_nowait(rms)
        except queue.Full:
            pass

    def writer_loop(self):
        while True:
            item = self.write_queue.get()
            if item is None:
                break
            self.writer.writeframesraw(item)
            self.frames_written += len(item) // 4
        self.writer.close()
        self.writer = None

    def start_record(self):
        if self.recording:
            return
        if self.stream is None:
            messagebox.showinfo('Grabación', 'Primero pulsa Iniciar audio.')
            return
        path = filedialog.asksaveasfilename(defaultextension='.wav', filetypes=[('Audio WAV', '*.wav')], initialfile='Coca_Broadcast_Prueba.wav')
        if not path:
            return
        try:
            self.writer = wave.open(path, 'wb')
            self.writer.setnchannels(2)
            self.writer.setsampwidth(2)
            self.writer.setframerate(RATE)
            self.frames_written = 0
            self.write_queue = queue.Queue(maxsize=256)
            self.writer_thread = threading.Thread(target=self.writer_loop, daemon=True)
            self.writer_thread.start()
            self.recording = True
            self.rec_status.set('Grabando: ' + os.path.basename(path))
        except Exception as exc:
            messagebox.showerror('Grabación', str(exc))

    def stop_record(self):
        if not self.recording:
            return
        self.recording = False
        self.write_queue.put(None)
        self.writer_thread.join(timeout=5)
        self.rec_status.set(f'Grabación finalizada ({self.frames_written / RATE:.1f} s).')

    def stop_audio(self):
        self.stop_record()
        if self.stream is not None:
            self.stream.stop()
            self.stream.close()
            self.stream = None
        self.meter.set(0)
        self.status.set('Audio detenido')

    def reset_hour_schedule(self):
        self.last_hour_slot = None

    def test_hour(self):
        self.request_hour_announcement(datetime.datetime.now())

    def request_hour_announcement(self, moment):
        if self.stream is None:
            self.hour_status.set('Primero pulsa Iniciar audio en CABINA.')
            return
        if self.announcement_generating or self.announcement_audio is not None:
            return
        self.announcement_generating = True
        self.hour_status.set('Preparando anuncio de la hora...')
        name = self.station_name.get().strip()[:60] or 'La radio'
        hour = moment.strftime('%I').lstrip('0')
        minute = moment.minute
        period = 'de la mañana' if moment.hour < 12 else ('de la tarde' if moment.hour < 19 else 'de la noche')
        if minute == 0:
            phrase = f'{name}. Son las {hour} {period}.'
        else:
            phrase = f'{name}. Son las {hour} y {minute} {period}.'
        if self.hour_source.get() == 'files':
            threading.Thread(target=self.generate_hour_from_file, args=(moment, phrase), daemon=True).start()
        else:
            threading.Thread(target=self.generate_announcement, args=(phrase,), daemon=True).start()

    def generate_hour_from_file(self, moment, phrase):
        try:
            audio = self.load_hour_recording(moment)
            if audio is not None:
                self.announcement_queue.put(('ok', audio), timeout=2)
                return
        except Exception:
            pass
        # Si no existe la grabación correspondiente, conserva la voz Windows.
        self.generate_announcement(phrase)

    def generate_announcement(self, phrase):
        # System.Speech: síntesis local de Windows PowerShell, sin conexión a Internet.
        path = None
        try:
            fd, path = tempfile.mkstemp(suffix='.wav')
            os.close(fd)
            # PowerShell recibe el texto mediante variables de entorno, evitando inyección.
            script = ("Add-Type -AssemblyName System.Speech; "
                      "$s=New-Object System.Speech.Synthesis.SpeechSynthesizer; "
                      "$v=$s.GetInstalledVoices() | Where-Object {$_.VoiceInfo.Culture.Name -like 'es-*'} | Select-Object -First 1; "
                      "if(-not $v){throw 'No hay voz en español instalada en Windows'}; "
                      "$s.SelectVoice($v.VoiceInfo.Name); "
                      "$s.SetOutputToWaveFile($env:COCA_WAV); "
                      "$s.Speak($env:COCA_TEXT); $s.Dispose()")
            env = os.environ.copy()
            env['COCA_WAV'] = path
            env['COCA_TEXT'] = phrase
            result = subprocess.run(['powershell.exe', '-NoProfile', '-NonInteractive', '-Command', script],
                                    capture_output=True, text=True, timeout=35, env=env, creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
            if result.returncode:
                raise RuntimeError((result.stderr or 'No se pudo generar la locución').strip()[-300:])
            data, rate = sf.read(path, dtype='float32', always_2d=True)
            if rate != RATE:
                divisor = math.gcd(rate, RATE)
                data = resample_poly(data, RATE // divisor, rate // divisor, axis=0).astype('float32')
            if data.shape[1] == 1:
                data = np.repeat(data, 2, axis=1)
            self.announcement_queue.put(('ok', data[:, :2]), timeout=2)
        except Exception as exc:
            try:
                self.announcement_queue.put(('error', str(exc)), timeout=2)
            except queue.Full:
                pass
        finally:
            if path:
                try:
                    os.unlink(path)
                except OSError:
                    pass

    def refresh(self):
        self.library_process_events()
        try:
            while True:
                result, payload = self.announcement_queue.get_nowait()
                self.announcement_generating = False
                if result == 'ok':
                    self.announcement_audio = payload
                    self.announcement_pos = 0
                    self.hour_status.set('Anuncio de hora reproduciéndose')
                else:
                    self.hour_status.set('Error de locución: ' + payload)
        except queue.Empty:
            pass
        now = datetime.datetime.now()
        interval = int(self.hour_interval.get())
        slot = now.strftime('%Y-%m-%d %H:%M')
        if self.hour_enabled.get() and now.minute % interval == 0 and slot != self.last_hour_slot:
            self.last_hour_slot = slot
            self.request_hour_announcement(now)

        try:
            while True:
                self.track_finished.get_nowait()
                self.songs_since_jingle += 1
                if self.auto_mode.get() and self.tracks and not self.playing:
                    if (self.jingle_auto.get() and self.jingle_paths and
                            self.songs_since_jingle >= int(self.jingle_every.get()) and
                            self.play_next_jingle()):
                        self.songs_since_jingle = 0
                    elif self.jingle_audio is None:
                        self.next_track()
        except queue.Empty:
            pass
        try:
            while True:
                self.jingle_finished.get_nowait()
                if self.auto_mode.get() and self.tracks and not self.playing:
                    self.next_track()
        except queue.Empty:
            pass
        try:
            while True:
                rms = self.meter_queue.get_nowait()
                self.meter.set(min(100, rms * 500))
        except queue.Empty:
            pass
        latest = None
        try:
            while True:
                latest = self.duck_events.get_nowait()
        except queue.Empty:
            pass
        if latest is not None:
            talking, factor, enabled, audio_on = latest
            percent = round(factor * 100)
            self.duck_meter.set(percent)
            if not enabled:
                label = 'AUTO DUCKING DESACTIVADO'
            elif self.mic_muted:
                label = 'MICRÓFONO SILENCIADO'
            elif talking:
                label = 'VOZ DETECTADA'
            else:
                label = 'SIN VOZ'
            self.duck_info.set(f'{label} • Música al {percent} % del nivel configurado')
        try:
            while True:
                readings = self.channel_meter_queue.get_nowait()
                for name, pair in readings.items():
                    if name in self.channel_levels:
                        for variable, rms in zip(self.channel_levels[name], pair):
                            variable.set(min(100.0, max(0.0, rms * 300)))
        except queue.Empty:
            pass
        try:
            while True:
                input_level = self.input_meter_queue.get_nowait()
                self.input_peak.set(min(100, input_level * 300))
        except queue.Empty:
            pass
        try:
            while True:
                l_level, r_level = self.output_meter_queue.get_nowait()
                self.output_left.set(min(100, l_level * 300))
                self.output_right.set(min(100, r_level * 300))
        except queue.Empty:
            pass
        if self.stream is None:
            self.input_peak.set(0)
            self.output_left.set(0)
            self.output_right.set(0)
        self.deck_refresh_visual()
        self.root.after(100, self.refresh)

    def close(self):
        self.save_playlist()
        self.save_cart_wall()
        self.save_branding()
        self.stop_audio()
        self.root.destroy()

if __name__ == '__main__':
    root = tk.Tk()
    App(root)
    root.mainloop()
