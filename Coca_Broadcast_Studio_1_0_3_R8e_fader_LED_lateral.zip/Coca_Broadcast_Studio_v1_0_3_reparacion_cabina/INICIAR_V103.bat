@echo off
cd /d "%~dp0"
py -3.13 coca_broadcast_v103.py
if errorlevel 1 pause
